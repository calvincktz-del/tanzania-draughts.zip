package com.example

import com.example.engine.AIDifficulty
import com.example.engine.DraughtsAI
import com.example.engine.TanzaniaDraughtsEngine
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test

class TanzaniaDraughtsEngineTest {

    @Test
    fun testInitialBoardSetup() {
        val state = GameState.initial()
        assertEquals(Player.PLAYER_1, state.currentTurn)
        assertEquals(GameStatus.IN_PROGRESS, state.status)

        // 12 pieces per player on 32 dark squares
        assertEquals(12, state.countPieces(Player.PLAYER_1))
        assertEquals(12, state.countPieces(Player.PLAYER_2))
        assertEquals(0, state.countKings(Player.PLAYER_1))
        assertEquals(0, state.countKings(Player.PLAYER_2))

        // All 24 pieces must reside on dark squares
        state.board.keys.forEach { pos ->
            assertTrue("Piece must be on dark square", pos.isDarkSquare)
        }
    }

    @Test
    fun testOrdinaryMenForwardMovement() {
        val state = GameState.initial()
        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, Player.PLAYER_1)

        // Initial legal moves for Player 1 from row 5
        assertTrue("Player 1 should have legal opening moves", legalMoves.isNotEmpty())
        legalMoves.forEach { move ->
            assertEquals(1, move.steps.size)
            assertFalse(move.isCapture)
            // Player 1 moves diagonally upwards (row decreases by 1)
            assertEquals(move.from.row - 1, move.to.row)
            assertTrue(move.to.row in 0..7 && move.to.col in 0..7)
        }
    }

    @Test
    fun testMandatoryCaptureEnforcement() {
        // Setup a board where Player 1 has a capture available
        // P1 Man at (5, 2) [C3], P2 Man at (4, 3) [D4], landing square at (3, 4) [E5] is empty
        val board = mapOf(
            Position(5, 2) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN),
            Position(4, 3) to DraughtsPiece(Player.PLAYER_2, PieceType.MAN),
            Position(6, 1) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN) // Another piece with ordinary moves
        )
        val state = GameState(
            board = board,
            currentTurn = Player.PLAYER_1,
            rulesConfig = RulesConfig()
        )

        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, Player.PLAYER_1)

        // Mandatory capture MUST exclude any non-capturing moves!
        assertTrue("Captures must exist", legalMoves.isNotEmpty())
        legalMoves.forEach { move ->
            assertTrue("Every legal move must be a capture when capture exists", move.isCapture)
            assertEquals(Position(5, 2), move.from)
            assertEquals(Position(3, 4), move.to)
            assertEquals(listOf(Position(4, 3)), move.capturedPositions)
        }
    }

    @Test
    fun testMultipleCaptureSequence() {
        // Setup a double jump for Player 1:
        // P1 at (6, 1), P2 at (5, 2), (4, 3) empty, P2 at (3, 4), (2, 5) empty
        val board = mapOf(
            Position(6, 1) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN),
            Position(5, 2) to DraughtsPiece(Player.PLAYER_2, PieceType.MAN),
            Position(3, 4) to DraughtsPiece(Player.PLAYER_2, PieceType.MAN)
        )
        val state = GameState(board = board, currentTurn = Player.PLAYER_1)

        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, Player.PLAYER_1)
        assertEquals(1, legalMoves.size)

        val doubleJump = legalMoves.first()
        assertEquals(2, doubleJump.captureCount)
        assertEquals(Position(6, 1), doubleJump.from)
        assertEquals(Position(2, 5), doubleJump.to)
        assertEquals(listOf(Position(5, 2), Position(3, 4)), doubleJump.capturedPositions)

        val nextState = TanzaniaDraughtsEngine.makeMove(state, doubleJump)
        // Both captured pieces must be removed
        assertNull(nextState.board[Position(5, 2)])
        assertNull(nextState.board[Position(3, 4)])
        assertNotNull(nextState.board[Position(2, 5)])
        assertEquals(2, nextState.capturedByP1)
    }

    @Test
    fun testKingPromotion() {
        // P1 man at (1, 2) moving to (0, 1) should be crowned as King
        val board = mapOf(
            Position(1, 2) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN)
        )
        val state = GameState(board = board, currentTurn = Player.PLAYER_1)

        val moves = TanzaniaDraughtsEngine.getLegalMoves(state, Player.PLAYER_1)
        val promoteMove = moves.first { it.to.row == 0 }

        val nextState = TanzaniaDraughtsEngine.makeMove(state, promoteMove)
        val promotedPiece = nextState.board[promoteMove.to]
        assertNotNull(promotedPiece)
        assertTrue("Piece must be promoted to King", promotedPiece!!.isKing)
        assertEquals(Player.PLAYER_1, promotedPiece.player)
    }

    @Test
    fun testFlyingKingMovementAndCapture() {
        // Tanzania flying king (Mfalme arukaye) can fly across multiple open squares diagonally
        // and jump over an opponent piece at long range
        val board = mapOf(
            Position(7, 0) to DraughtsPiece(Player.PLAYER_1, PieceType.KING),
            Position(4, 3) to DraughtsPiece(Player.PLAYER_2, PieceType.MAN)
            // (6,1) and (5,2) are empty before P2 piece; (3,4), (2,5), (1,6), (0,7) are empty beyond
        )
        val state = GameState(board = board, currentTurn = Player.PLAYER_1)

        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, Player.PLAYER_1)
        assertTrue("Flying king should find capture", legalMoves.isNotEmpty())

        val captureLandingSquares = legalMoves.map { it.to }.toSet()
        // The king should be able to land on multiple empty squares beyond (4,3): (3,4), (2,5), (1,6), (0,7)
        assertTrue(captureLandingSquares.contains(Position(3, 4)))
        assertTrue(captureLandingSquares.contains(Position(2, 5)))
        assertTrue(captureLandingSquares.contains(Position(1, 6)))
        assertTrue(captureLandingSquares.contains(Position(0, 7)))

        // Test executing one of the long-range landings
        val chosenMove = legalMoves.first { it.to == Position(1, 6) }
        val nextState = TanzaniaDraughtsEngine.makeMove(state, chosenMove)

        assertNull("Captured piece at (4,3) should be removed", nextState.board[Position(4, 3)])
        val landingPiece = nextState.board[Position(1, 6)]
        assertNotNull(landingPiece)
        assertTrue(landingPiece!!.isKing)
    }

    @Test
    fun testVictoryWhenOpponentHasNoPieces() {
        // P1 has 1 man, P2 has 1 man with capture immediately available
        val board = mapOf(
            Position(3, 2) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN),
            Position(2, 3) to DraughtsPiece(Player.PLAYER_2, PieceType.MAN)
        )
        val state = GameState(board = board, currentTurn = Player.PLAYER_1)
        val moves = TanzaniaDraughtsEngine.getLegalMoves(state, Player.PLAYER_1)
        assertEquals(1, moves.size)

        val winningMove = moves.first()
        val nextState = TanzaniaDraughtsEngine.makeMove(state, winningMove)

        assertEquals(0, nextState.countPieces(Player.PLAYER_2))
        assertEquals(GameStatus.PLAYER_1_WON, nextState.status)
        assertTrue(nextState.isGameOver)
    }

    @Test
    fun testVictoryWhenOpponentIsBlocked() {
        // P2 has a piece that is completely trapped and has no legal moves
        // P2 piece at (0, 7), surrounded by board boundaries and P1 piece at (1, 6) with no jumps possible
        val board = mapOf(
            Position(0, 7) to DraughtsPiece(Player.PLAYER_2, PieceType.MAN),
            Position(1, 6) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN),
            Position(2, 5) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN),
            Position(5, 2) to DraughtsPiece(Player.PLAYER_1, PieceType.MAN)
        )
        // P1 makes a quiet move that leaves P2 with 0 legal moves
        val state = GameState(board = board, currentTurn = Player.PLAYER_1)
        val legalP2Moves = TanzaniaDraughtsEngine.getLegalMoves(
            state.copy(currentTurn = Player.PLAYER_2),
            Player.PLAYER_2
        )
        assertEquals("P2 should be blocked", 0, legalP2Moves.size)
    }

    @Test
    fun testAiGeneratesOnlyLegalMoves() {
        val state = GameState.initial()
        val ai = DraughtsAI(AIDifficulty.MEDIUM)

        val bestMove = ai.findBestMove(state)
        assertNotNull("AI should return a move", bestMove)

        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, state.currentTurn)
        assertTrue("AI move must be in legal moves list", legalMoves.contains(bestMove))
    }
}
