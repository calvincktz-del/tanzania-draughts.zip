package com.example.model

/**
 * Representation of a player in Tanzania Draughts.
 * Player 1: Typically Light / Gold / Green pieces (moves upwards: from row 7 towards row 0).
 * Player 2: Typically Dark / Black / Red pieces (moves downwards: from row 0 towards row 7).
 */
enum class Player {
    PLAYER_1,
    PLAYER_2;

    fun opponent(): Player = if (this == PLAYER_1) PLAYER_2 else PLAYER_1
}

/**
 * Piece types in 8x8 Tanzania Draughts (Dama ya Kitanzania).
 */
enum class PieceType {
    MAN,
    KING // Mfalme (Flying King / Arukaye)
}

data class DraughtsPiece(
    val player: Player,
    val type: PieceType = PieceType.MAN
) {
    val isKing: Boolean get() = type == PieceType.KING
}

/**
 * Board coordinate on an 8x8 draughts board.
 * Rows: 0..7 (0 is Player 2's back rank, 7 is Player 1's back rank).
 * Cols: 0..7.
 * Only dark squares where (row + col) % 2 != 0 are playable.
 */
data class Position(val row: Int, val col: Int) {
    val isValid: Boolean get() = row in 0..7 && col in 0..7 && isDarkSquare

    val isDarkSquare: Boolean get() = (row + col) % 2 != 0

    fun toNotation(): String {
        val colLetter = ('A'.code + col).toChar()
        val rowNumber = 8 - row
        return "$colLetter$rowNumber"
    }

    companion object {
        fun fromNotation(notation: String): Position? {
            if (notation.length != 2) return null
            val col = notation[0].uppercaseChar() - 'A'
            val rowNum = notation[1].digitToIntOrNull() ?: return null
            val row = 8 - rowNum
            val pos = Position(row, col)
            return if (pos.isValid) pos else null
        }
    }
}

/**
 * Single step within a move (either ordinary move or one step of a capture sequence).
 */
data class MoveStep(
    val from: Position,
    val to: Position,
    val capturedPos: Position? = null
)

/**
 * Complete Draughts Move.
 * A move may consist of 1 step (simple move or single capture) or multiple steps (consecutive captures).
 */
data class DraughtsMove(
    val steps: List<MoveStep>,
    val promotesToKing: Boolean = false
) {
    val from: Position get() = steps.first().from
    val to: Position get() = steps.last().to
    val isCapture: Boolean get() = steps.any { it.capturedPos != null }
    val capturedPositions: List<Position> get() = steps.mapNotNull { it.capturedPos }
    val captureCount: Int get() = capturedPositions.size

    fun notation(): String {
        if (!isCapture) {
            return "${from.toNotation()}-${to.toNotation()}"
        }
        val points = mutableListOf(from.toNotation())
        steps.forEach { points.add(it.to.toNotation()) }
        return points.joinToString("x")
    }
}

/**
 * Rule configuration for the Tanzania Draughts League.
 */
enum class CaptureChoiceRule {
    FREE_CHOICE,    // Player can freely choose among any legal capture path
    MAXIMUM_PIECES  // Player must choose a capture path that takes the maximum number of pieces
}

data class RulesConfig(
    val rulesetVersion: String = "TDL-2024.1",
    val captureChoiceRule: CaptureChoiceRule = CaptureChoiceRule.FREE_CHOICE,
    val menCanCaptureBackward: Boolean = false, // In default Tanzania Draughts, men only capture forward
    val flyingKingsEnabled: Boolean = true,     // Mfalme arukaye (long-range diagonal movement)
    val kingHaltsOnPromotion: Boolean = true,  // Does a piece stop moving on the turn it gets crowned?
    val maxMovesWithoutCapture: Int = 40        // Move limit for endgame draw rule
)

/**
 * Game outcome status.
 */
enum class GameStatus {
    IN_PROGRESS,
    PLAYER_1_WON,
    PLAYER_2_WON,
    DRAW_MUTUAL,
    DRAW_MOVE_LIMIT,
    DRAW_REPETITION,
    PLAYER_1_RESIGNED,
    PLAYER_2_RESIGNED,
    TIMEOUT
}
