package com.example.model

/**
 * Immutable GameState holding the complete snapshot of the draughts board and match state.
 */
data class GameState(
    val board: Map<Position, DraughtsPiece> = emptyMap(),
    val currentTurn: Player = Player.PLAYER_1,
    val status: GameStatus = GameStatus.IN_PROGRESS,
    val rulesConfig: RulesConfig = RulesConfig(),
    val moveHistory: List<DraughtsMove> = emptyList(),
    val halfMoveClockWithoutCapture: Int = 0,
    val capturedByP1: Int = 0,
    val capturedByP2: Int = 0,
    val selectedPosition: Position? = null,
    val activeMultiStepMove: List<MoveStep>? = null // When mid-turn multi-step capture is occurring
) {
    val isGameOver: Boolean get() = status != GameStatus.IN_PROGRESS

    fun pieceAt(pos: Position): DraughtsPiece? = board[pos]

    fun countPieces(player: Player): Int {
        return board.values.count { it.player == player }
    }

    fun countKings(player: Player): Int {
        return board.values.count { it.player == player && it.isKing }
    }

    fun countMen(player: Player): Int {
        return board.values.count { it.player == player && !it.isKing }
    }

    companion object {
        /**
         * Standard starting position for 8x8 Tanzania Draughts.
         * 12 pieces per player placed on the 32 dark squares.
         * P2 pieces on rows 0, 1, 2.
         * P1 pieces on rows 5, 6, 7.
         * Rows 3 and 4 are empty.
         */
        fun initial(rulesConfig: RulesConfig = RulesConfig()): GameState {
            val pieces = mutableMapOf<Position, DraughtsPiece>()
            for (row in 0..7) {
                for (col in 0..7) {
                    val pos = Position(row, col)
                    if (pos.isDarkSquare) {
                        when (row) {
                            0, 1, 2 -> pieces[pos] = DraughtsPiece(Player.PLAYER_2, PieceType.MAN)
                            5, 6, 7 -> pieces[pos] = DraughtsPiece(Player.PLAYER_1, PieceType.MAN)
                        }
                    }
                }
            }
            return GameState(
                board = pieces,
                currentTurn = Player.PLAYER_1,
                status = GameStatus.IN_PROGRESS,
                rulesConfig = rulesConfig
            )
        }
    }
}
