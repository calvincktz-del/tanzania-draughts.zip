package com.example.model

enum class LeagueStatus {
    DRAFT,
    REGISTRATION_OPEN,
    REGISTRATION_CLOSED,
    ACTIVE,
    COMPLETED
}

enum class CompetitionFormat {
    ROUND_ROBIN,
    KNOCKOUT,
    GROUP_STAGE_AND_KNOCKOUT
}

data class League(
    val leagueId: String,
    val name: String,
    val nameSwahili: String,
    val season: String = "Msimu wa 2026/2027",
    val description: String,
    val descriptionSwahili: String,
    val division: String, // Champion, Elite, Advanced, Intermediate, Amateur
    val format: CompetitionFormat = CompetitionFormat.ROUND_ROBIN,
    val rulesetVersion: String = "TDL-2024.1",
    val status: LeagueStatus = LeagueStatus.ACTIVE,
    val participantCapacity: Int = 12,
    val registeredCount: Int = 12,
    val startDate: String = "01 Novemba 2026",
    val endDate: String = "20 Desemba 2026",
    val isRegistered: Boolean = false
)

data class LeagueParticipant(
    val participantId: String,
    val rank: Int,
    val playerName: String,
    val clubOrRegion: String,
    val avatarEmoji: String,
    val points: Int,
    val matchesPlayed: Int,
    val wins: Int,
    val draws: Int,
    val losses: Int,
    val skillRating: Int,
    val form: List<String> = listOf("W", "W", "D", "W", "W") // Recent results
) {
    val winRate: Int
        get() = if (matchesPlayed > 0) ((wins.toDouble() / matchesPlayed) * 100).toInt() else 0
}

enum class FixtureStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED
}

data class Fixture(
    val fixtureId: String,
    val leagueId: String,
    val round: Int,
    val roundLabel: String,
    val playerA: String,
    val playerB: String,
    val scheduledTime: String,
    val venueOrOnline: String = "Online / Dar es Salaam Arena",
    val status: FixtureStatus = FixtureStatus.SCHEDULED,
    val scoreA: Int = 0,
    val scoreB: Int = 0,
    val winner: String? = null
)

data class TournamentMatch(
    val matchId: String,
    val roundName: String,
    val playerA: String,
    val playerB: String,
    val scoreA: Int? = null,
    val scoreB: Int? = null,
    val winner: String? = null
)

data class TournamentBracket(
    val tournamentId: String,
    val name: String,
    val nameSwahili: String,
    val quarterFinals: List<TournamentMatch>,
    val semiFinals: List<TournamentMatch>,
    val finalMatch: TournamentMatch,
    val champion: String? = null
)

data class DisputeReport(
    val reportId: String,
    val reporterName: String,
    val matchId: String,
    val category: String, // "Matokeo Yasiyo Sahihi", "Kukatika Mtandao", "Ukiukaji wa Sheria"
    val description: String,
    val status: String = "Inakaguliwa (Under Review)", // "Resolved", "Dismissed"
    val timestamp: String = "28 Okt 2026, 11:45 EAT",
    val adminResolution: String? = null
)

data class AuditLog(
    val logId: String,
    val actor: String,
    val role: String,
    val action: String,
    val target: String,
    val timestamp: String
)
