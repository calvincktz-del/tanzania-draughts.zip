package com.example.model

enum class AppLanguage {
    SWAHILI,
    ENGLISH
}

enum class BoardThemeStyle(
    val titleEn: String,
    val titleSw: String,
    val lightSquareHex: Long,
    val darkSquareHex: Long,
    val accentHex: Long
) {
    SERENGETI_DARK(
        "Serengeti Forest",
        "Msitu wa Serengeti",
        0xFFE0E0E0,
        0xFF1C3A27,
        0xFFFFD700
    ),
    CLASSIC_WOOD(
        "Zanzibar Mahogany",
        "Mninga wa Zanzibar",
        0xFFF0D9B5,
        0xFFB58863,
        0xFFD4AF37
    ),
    KILIMANJARO_OBSIDIAN(
        "Kilimanjaro Gold",
        "Dhahabu ya Kilimanjaro",
        0xFFF5F5F5,
        0xFF212121,
        0xFFFFC107
    ),
    DAR_OCEAN(
        "Dar Indian Ocean",
        "Bahari ya Hindi Dar",
        0xFFE3F2FD,
        0xFF0D47A1,
        0xFF00E676
    )
}

data class Achievement(
    val id: String,
    val titleSw: String,
    val titleEn: String,
    val descriptionSw: String,
    val descriptionEn: String,
    val iconEmoji: String,
    val isUnlocked: Boolean = false
)

data class PlayerProfile(
    val uid: String = "tz_player_001",
    val username: String = "Juma_Fundi",
    val displayName: String = "Juma 'Fundi' Mwamba",
    val region: String = "Dar es Salaam (Kinondoni)",
    val avatarEmoji: String = "👑",
    val skillRating: Int = 1580,
    val division: String = "Elite / Stadi",
    val matchesPlayed: Int = 48,
    val wins: Int = 34,
    val losses: Int = 9,
    val draws: Int = 5,
    val level: Int = 8,
    val xp: Int = 2450,
    val nextLevelXp: Int = 3000,
    val trophiesCount: Int = 6,
    val registrationDate: String = "15 Jan 2026",
    val accountStatus: String = "Imeidhinishwa (Verified)",
    val achievements: List<Achievement> = listOf(
        Achievement(
            "ach_first_win",
            "Ushindi wa Kwanza",
            "First Victory",
            "Shinda mchezo wako wa kwanza wa Rasimu",
            "Win your first draughts game",
            "🏆",
            true
        ),
        Achievement(
            "ach_flying_king",
            "Mfalme Arukaye",
            "Flying King Master",
            "Tengeneza na tawala ubao kwa mfalme wa kwanza",
            "Promote and dominate the board with a king",
            "👑",
            true
        ),
        Achievement(
            "ach_triple_jump",
            "Kula Tatu (Triple Jump)",
            "Triple Strike",
            "Kula kete 3 mfululizo kwa mzunguko mmoja",
            "Capture 3 opposing pieces in a single turn",
            "⚡",
            true
        ),
        Achievement(
            "ach_dar_derby",
            "Ubingwa wa Ligi",
            "League Champion",
            "Kamilisha mechi 10 za Ligi Kuu ya Rasimu",
            "Complete 10 Tanzania League matches",
            "🥇",
            true
        ),
        Achievement(
            "ach_grandmaster",
            "Gwiji wa Rasimu",
            "Grandmaster",
            "Fikisha rating ya Elo 1700+",
            "Reach an Elo rating of 1700+",
            "🌟",
            false
        )
    )
) {
    val winRate: Int
        get() = if (matchesPlayed > 0) ((wins.toDouble() / matchesPlayed) * 100).toInt() else 0
}

data class MatchRecord(
    val matchId: String,
    val opponentName: String,
    val opponentRating: Int,
    val result: String, // "WIN", "LOSS", "DRAW"
    val date: String,
    val mode: String, // "Ligi Kuu", "AI (Expert)", "Online Ranked"
    val notationMoves: List<String> = listOf("C3-D4", "F6-E5", "D4xF6", "G7xE5", "B2-C3", "H8-G7")
)
