package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class DraughtsRepository {

    private val _language = MutableStateFlow(AppLanguage.SWAHILI)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _boardTheme = MutableStateFlow(BoardThemeStyle.SERENGETI_DARK)
    val boardTheme: StateFlow<BoardThemeStyle> = _boardTheme.asStateFlow()

    private val _rulesConfig = MutableStateFlow(RulesConfig())
    val rulesConfig: StateFlow<RulesConfig> = _rulesConfig.asStateFlow()

    private val _profile = MutableStateFlow(PlayerProfile())
    val profile: StateFlow<PlayerProfile> = _profile.asStateFlow()

    private val _leagues = MutableStateFlow(createInitialLeagues())
    val leagues: StateFlow<List<League>> = _leagues.asStateFlow()

    private val _standings = MutableStateFlow(createInitialStandings())
    val standings: StateFlow<List<LeagueParticipant>> = _standings.asStateFlow()

    private val _fixtures = MutableStateFlow(createInitialFixtures())
    val fixtures: StateFlow<List<Fixture>> = _fixtures.asStateFlow()

    private val _tournament = MutableStateFlow(createInitialTournament())
    val tournament: StateFlow<TournamentBracket> = _tournament.asStateFlow()

    private val _matchHistory = MutableStateFlow(createInitialMatchHistory())
    val matchHistory: StateFlow<List<MatchRecord>> = _matchHistory.asStateFlow()

    private val _disputes = MutableStateFlow(createInitialDisputes())
    val disputes: StateFlow<List<DisputeReport>> = _disputes.asStateFlow()

    private val _auditLogs = MutableStateFlow(createInitialAuditLogs())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    fun toggleLanguage() {
        _language.update {
            if (it == AppLanguage.SWAHILI) AppLanguage.ENGLISH else AppLanguage.SWAHILI
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    fun setBoardTheme(theme: BoardThemeStyle) {
        _boardTheme.value = theme
    }

    fun updateRulesConfig(config: RulesConfig) {
        _rulesConfig.value = config
        logAudit("Admin", "LEAGUE_ADMIN", "UPDATE_RULES", "ruleset: ${config.rulesetVersion}")
    }

    fun toggleAdminMode() {
        _isAdmin.update { !it }
    }

    fun registerForLeague(leagueId: String) {
        _leagues.update { list ->
            list.map { league ->
                if (league.leagueId == leagueId) {
                    league.copy(isRegistered = true, registeredCount = league.registeredCount + 1)
                } else league
            }
        }
    }

    fun recordGameResult(result: String, opponentName: String, opponentRating: Int, notationMoves: List<String>) {
        val dateStr = "28 Okt 2026"
        val record = MatchRecord(
            matchId = "M-${System.currentTimeMillis() % 100000}",
            opponentName = opponentName,
            opponentRating = opponentRating,
            result = result,
            date = dateStr,
            mode = "Tanzania Draughts",
            notationMoves = notationMoves
        )
        _matchHistory.update { listOf(record) + it }

        // Update profile stats and XP
        _profile.update { p ->
            val isWin = result == "WIN"
            val isDraw = result == "DRAW"
            val xpGain = if (isWin) 120 else if (isDraw) 50 else 25
            val ratingChange = if (isWin) 15 else if (isDraw) 0 else -10
            p.copy(
                matchesPlayed = p.matchesPlayed + 1,
                wins = if (isWin) p.wins + 1 else p.wins,
                losses = if (!isWin && !isDraw) p.losses + 1 else p.losses,
                draws = if (isDraw) p.draws + 1 else p.draws,
                skillRating = (p.skillRating + ratingChange).coerceAtLeast(1000),
                xp = p.xp + xpGain
            )
        }
    }

    fun submitDispute(reporter: String, matchId: String, category: String, desc: String) {
        val report = DisputeReport(
            reportId = "DISP-${System.currentTimeMillis() % 10000}",
            reporterName = reporter,
            matchId = matchId,
            category = category,
            description = desc,
            status = "Inakaguliwa (Under Review)"
        )
        _disputes.update { listOf(report) + it }
        logAudit(reporter, "PLAYER", "SUBMIT_DISPUTE", "Report ${report.reportId}")
    }

    fun resolveDispute(reportId: String, resolutionText: String, approved: Boolean) {
        _disputes.update { list ->
            list.map {
                if (it.reportId == reportId) {
                    it.copy(
                        status = if (approved) "Imeamuliwa (Resolved)" else "Imetupiliwa Mbali (Dismissed)",
                        adminResolution = resolutionText
                    )
                } else it
            }
        }
        logAudit("Admin", "LEAGUE_ADMIN", "RESOLVE_DISPUTE", "$reportId -> $resolutionText")
    }

    fun generateNewFixtures() {
        val roundNum = _fixtures.value.maxOfOrNull { it.round }?.plus(1) ?: 1
        val newF = listOf(
            Fixture("FIX-$roundNum-1", "TZ-PREMIER", roundNum, "Raundi ya $roundNum", "Juma Mwamba", "Bakari 'Kete' Salum", "05 Nov 2026, 17:00 EAT"),
            Fixture("FIX-$roundNum-2", "TZ-PREMIER", roundNum, "Raundi ya $roundNum", "Rashid 'Mfalme' Ali", "Baraka 'Simba' Mrosso", "05 Nov 2026, 19:30 EAT")
        )
        _fixtures.update { it + newF }
        logAudit("Admin", "LEAGUE_ADMIN", "GENERATE_FIXTURES", "Round $roundNum generated")
    }

    private fun logAudit(actor: String, role: String, action: String, target: String) {
        val log = AuditLog(
            logId = "LOG-${System.currentTimeMillis() % 100000}",
            actor = actor,
            role = role,
            action = action,
            target = target,
            timestamp = "28 Okt 2026, 12:00 EAT"
        )
        _auditLogs.update { listOf(log) + it }
    }

    companion object {
        fun createInitialLeagues(): List<League> {
            return listOf(
                League(
                    leagueId = "TZ-PREMIER",
                    name = "Tanzania Premier Draughts League",
                    nameSwahili = "Ligi Kuu ya Rasimu Tanzania (TLD Premier)",
                    season = "Msimu wa 2026/2027",
                    description = "The premier professional draughts championship in Tanzania featuring top national masters.",
                    descriptionSwahili = "Ligi daraja la kwanza ya kitaifa inayowakutanisha magwiji wa rasimu kutoka kote Tanzania.",
                    division = "Champion / Daraja la Kwanza",
                    rulesetVersion = "TDL-2024.1",
                    status = LeagueStatus.ACTIVE,
                    participantCapacity = 16,
                    registeredCount = 14,
                    startDate = "01 Nov 2026",
                    endDate = "20 Des 2026",
                    isRegistered = true
                ),
                League(
                    leagueId = "TZ-DAR",
                    name = "Dar es Salaam & Coastal Regional Championship",
                    nameSwahili = "Ligi ya Dar es Salaam na Pwani",
                    season = "Msimu wa 2026",
                    description = "Competitive regional circuit across Ilala, Kinondoni, Temeke, and Pwani.",
                    descriptionSwahili = "Mashindano ya kanda ya Dar es Salaam na Pwani kuibua mabingwa wa mitaani na klabu.",
                    division = "Elite / Stadi",
                    rulesetVersion = "TDL-2024.1",
                    status = LeagueStatus.REGISTRATION_OPEN,
                    participantCapacity = 20,
                    registeredCount = 12,
                    startDate = "15 Nov 2026",
                    endDate = "30 Des 2026",
                    isRegistered = false
                ),
                League(
                    leagueId = "TZ-MUUNGANO",
                    name = "Muungano Draughts Cup (Knockout)",
                    nameSwahili = "Kombe la Muungano wa Tanzania (Mtoano)",
                    season = "2026",
                    description = "Prestigious national knockout tournament bringing Mainland and Zanzibar players together.",
                    descriptionSwahili = "Mashindano ya mtoano ya kitaifa yanayowaunganisha wachezaji wa Tanzania Bara na Zanzibar.",
                    division = "Open / Wazi",
                    format = CompetitionFormat.KNOCKOUT,
                    rulesetVersion = "TDL-2024.1",
                    status = LeagueStatus.ACTIVE,
                    participantCapacity = 32,
                    registeredCount = 32,
                    startDate = "25 Okt 2026",
                    endDate = "10 Nov 2026",
                    isRegistered = true
                ),
                League(
                    leagueId = "TZ-YOUTH",
                    name = "Tanzania Youth & Amateur League",
                    nameSwahili = "Ligi ya Vijana na Chipukizi",
                    season = "Msimu wa 2026",
                    description = "Developmental league for rising stars and recreational enthusiasts.",
                    descriptionSwahili = "Ligi ya kuwanoa wachezaji wachanga na kukuza vipaji vya rasimu mashuleni na mitaani.",
                    division = "Amateur / Chipukizi",
                    rulesetVersion = "TDL-2024.1",
                    status = LeagueStatus.REGISTRATION_OPEN,
                    participantCapacity = 24,
                    registeredCount = 9,
                    startDate = "01 Des 2026",
                    endDate = "15 Jan 2027",
                    isRegistered = false
                )
            )
        }

        fun createInitialStandings(): List<LeagueParticipant> {
            return listOf(
                LeagueParticipant("p1", 1, "Juma 'Fundi' Mwamba", "Kinondoni, DSM", "👑", points = 24, matchesPlayed = 9, wins = 8, draws = 0, losses = 1, skillRating = 1680, form = listOf("W", "W", "W", "W", "W")),
                LeagueParticipant("p2", 2, "Bakari 'Kete' Salum", "Kariakoo, DSM", "⚡", points = 21, matchesPlayed = 9, wins = 6, draws = 3, losses = 0, skillRating = 1645, form = listOf("W", "D", "W", "W", "D")),
                LeagueParticipant("p3", 3, "Rashid 'Mfalme' Ali", "Mlandege, Zanzibar", "🏆", points = 19, matchesPlayed = 9, wins = 6, draws = 1, losses = 2, skillRating = 1610, form = listOf("W", "L", "W", "W", "D")),
                LeagueParticipant("p4", 4, "Baraka 'Simba' Mrosso", "Arusha Mjini", "🦁", points = 18, matchesPlayed = 9, wins = 5, draws = 3, losses = 1, skillRating = 1590, form = listOf("D", "W", "W", "D", "W")),
                LeagueParticipant("p5", 5, "Hamisi 'Mbinu' Ndolela", "Mwanza Nyamagana", "🎯", points = 15, matchesPlayed = 9, wins = 4, draws = 3, losses = 2, skillRating = 1540, form = listOf("W", "D", "L", "W", "D")),
                LeagueParticipant("p6", 6, "Zuberi 'Upepo' Kasisi", "Tanga Mjini", "🌪️", points = 13, matchesPlayed = 9, wins = 4, draws = 1, losses = 4, skillRating = 1510, form = listOf("L", "W", "L", "W", "W")),
                LeagueParticipant("p7", 7, "Frank 'Mwewe' Temu", "Moshi, Kilimanjaro", "🦅", points = 10, matchesPlayed = 9, wins = 3, draws = 1, losses = 5, skillRating = 1480, form = listOf("L", "L", "W", "D", "L")),
                LeagueParticipant("p8", 8, "Iddi 'Bundi' Ramadhani", "Dodoma Makulu", "🦉", points = 8, matchesPlayed = 9, wins = 2, draws = 2, losses = 5, skillRating = 1430, form = listOf("D", "L", "L", "W", "L"))
            )
        }

        fun createInitialFixtures(): List<Fixture> {
            return listOf(
                Fixture("FIX-1", "TZ-PREMIER", 10, "Mzunguko wa 10", "Juma 'Fundi' Mwamba", "Bakari 'Kete' Salum", "29 Okt 2026, 16:00 EAT", status = FixtureStatus.SCHEDULED),
                Fixture("FIX-2", "TZ-PREMIER", 10, "Mzunguko wa 10", "Rashid 'Mfalme' Ali", "Baraka 'Simba' Mrosso", "29 Okt 2026, 17:30 EAT", status = FixtureStatus.SCHEDULED),
                Fixture("FIX-3", "TZ-PREMIER", 10, "Mzunguko wa 10", "Hamisi 'Mbinu' Ndolela", "Zuberi 'Upepo' Kasisi", "29 Okt 2026, 19:00 EAT", status = FixtureStatus.SCHEDULED),
                Fixture("FIX-4", "TZ-PREMIER", 9, "Mzunguko wa 9", "Juma 'Fundi' Mwamba", "Frank 'Mwewe' Temu", "24 Okt 2026, 16:00 EAT", status = FixtureStatus.COMPLETED, scoreA = 1, scoreB = 0, winner = "Juma 'Fundi' Mwamba"),
                Fixture("FIX-5", "TZ-PREMIER", 9, "Mzunguko wa 9", "Bakari 'Kete' Salum", "Iddi 'Bundi' Ramadhani", "24 Okt 2026, 17:30 EAT", status = FixtureStatus.COMPLETED, scoreA = 1, scoreB = 0, winner = "Bakari 'Kete' Salum")
            )
        }

        fun createInitialTournament(): TournamentBracket {
            val qf = listOf(
                TournamentMatch("TM-1", "Robo Fainali 1", "Juma Mwamba", "Iddi Ramadhani", 1, 0, "Juma Mwamba"),
                TournamentMatch("TM-2", "Robo Fainali 2", "Baraka Mrosso", "Hamisi Ndolela", 1, 0, "Baraka Mrosso"),
                TournamentMatch("TM-3", "Robo Fainali 3", "Bakari Salum", "Frank Temu", 1, 0, "Bakari Salum"),
                TournamentMatch("TM-4", "Robo Fainali 4", "Rashid Ali", "Zuberi Kasisi", 1, 0, "Rashid Ali")
            )
            val sf = listOf(
                TournamentMatch("TM-5", "Nusu Fainali 1", "Juma Mwamba", "Baraka Mrosso", 1, 0, "Juma Mwamba"),
                TournamentMatch("TM-6", "Nusu Fainali 2", "Bakari Salum", "Rashid Ali", null, null, null)
            )
            val finalMatch = TournamentMatch("TM-7", "Fainali Kuu", "Juma Mwamba", "Mshindi SF 2", null, null, null)

            return TournamentBracket(
                tournamentId = "TOURN-MUUNGANO-2026",
                name = "Muungano Cup Knockout 2026",
                nameSwahili = "Kombe la Muungano wa Tanzania 2026",
                quarterFinals = qf,
                semiFinals = sf,
                finalMatch = finalMatch,
                champion = null
            )
        }

        fun createInitialMatchHistory(): List<MatchRecord> {
            return listOf(
                MatchRecord("M-891", "Bakari 'Kete' Salum", 1640, "WIN", "26 Okt 2026", "Ligi Kuu (Mzunguko 9)", listOf("C3-D4", "F6-E5", "D4xF6", "G7xE5", "B2-C3", "C7-D6")),
                MatchRecord("M-872", "Rashid 'Mfalme' Ali", 1615, "DRAW", "21 Okt 2026", "Ligi Kuu (Mzunguko 8)", listOf("C3-D4", "B6-A5", "D4-E5", "F6xD4", "E3xC5", "D6xB4")),
                MatchRecord("M-855", "AI (Expert)", 1700, "WIN", "19 Okt 2026", "Mazoezi ya AI", listOf("E3-D4", "D6-C5", "D4xB6", "A7xC5", "C3-D4", "F6-E5")),
                MatchRecord("M-840", "Baraka 'Simba' Mrosso", 1590, "WIN", "15 Okt 2026", "Ligi Kuu (Mzunguko 7)", listOf("C3-D4", "F6-E5", "B2-C3", "G7-F6", "D4-C5", "B6xD4"))
            )
        }

        fun createInitialDisputes(): List<DisputeReport> {
            return listOf(
                DisputeReport(
                    reportId = "DISP-104",
                    reporterName = "Zuberi Kasisi",
                    matchId = "FIX-3",
                    category = "Kukatika Mtandao (Disconnection)",
                    description = "Mchezaji mpinzani alitoka katikati ya mchezo kabla ya muda kumalizika.",
                    status = "Inakaguliwa (Under Review)",
                    timestamp = "27 Okt 2026, 18:20 EAT"
                ),
                DisputeReport(
                    reportId = "DISP-102",
                    reporterName = "Frank Temu",
                    matchId = "FIX-4",
                    category = "Uhakiki wa Matokeo",
                    description = "Uhakiki wa alama za ubao na kete za mwisho.",
                    status = "Imeamuliwa (Resolved)",
                    timestamp = "24 Okt 2026, 20:10 EAT",
                    adminResolution = "Matokeo yamethibitishwa kuwa halali baada ya kukagua kumbukumbu za miondoko (move notation)."
                )
            )
        }

        fun createInitialAuditLogs(): List<AuditLog> {
            return listOf(
                AuditLog("LOG-1", "Admin_Hassan", "LEAGUE_ADMIN", "APPROVE_PARTICIPANT", "p1 (Juma Mwamba) -> TZ-PREMIER", "25 Okt 2026, 09:15 EAT"),
                AuditLog("LOG-2", "Admin_Hassan", "LEAGUE_ADMIN", "PUBLISH_RULESET", "Version TDL-2024.1 published", "25 Okt 2026, 10:00 EAT"),
                AuditLog("LOG-3", "Referee_Daudi", "REFEREE", "CONFIRM_RESULT", "Match FIX-4 confirmed: 1-0", "24 Okt 2026, 17:45 EAT")
            )
        }
    }
}
