package com.example.engine

import com.example.model.*
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

enum class AIDifficulty {
    BEGINNER,
    EASY,
    MEDIUM,
    HARD,
    EXPERT
}

/**
 * Intelligent AI opponent for Tanzania Draughts.
 * Uses legal move generation from TanzaniaDraughtsEngine, board evaluation,
 * and Minimax with Alpha-Beta Pruning.
 */
class DraughtsAI(private val difficulty: AIDifficulty = AIDifficulty.MEDIUM) {

    // Positional value weights: center dark squares are strategically powerful
    private val centerControl = arrayOf(
        intArrayOf(0, 0, 0, 0, 0, 0, 0, 0),
        intArrayOf(0, 10, 0, 10, 0, 10, 0, 5),
        intArrayOf(5, 0, 15, 0, 15, 0, 10, 0),
        intArrayOf(0, 15, 0, 25, 0, 25, 0, 10),
        intArrayOf(10, 0, 25, 0, 25, 0, 15, 0),
        intArrayOf(0, 10, 0, 15, 0, 15, 0, 5),
        intArrayOf(5, 0, 10, 0, 10, 0, 10, 0),
        intArrayOf(0, 0, 0, 0, 0, 0, 0, 0)
    )

    fun findBestMove(state: GameState): DraughtsMove? {
        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, state.currentTurn)
        if (legalMoves.isEmpty()) return null
        if (legalMoves.size == 1) return legalMoves.first()

        return when (difficulty) {
            AIDifficulty.BEGINNER -> {
                // 70% random, 30% capture preference
                if (Random.nextFloat() < 0.7f) {
                    legalMoves.random()
                } else {
                    legalMoves.maxByOrNull { it.captureCount } ?: legalMoves.random()
                }
            }
            AIDifficulty.EASY -> {
                // 1-ply greedy search with slight noise
                legalMoves.shuffled().maxByOrNull { move ->
                    val nextState = TanzaniaDraughtsEngine.makeMove(state, move)
                    evaluateBoard(nextState, state.currentTurn) + Random.nextInt(-20, 20)
                } ?: legalMoves.first()
            }
            AIDifficulty.MEDIUM -> {
                // 3-ply minimax with alpha-beta
                minimaxRoot(state, depth = 3)
            }
            AIDifficulty.HARD -> {
                // 4-ply minimax with alpha-beta
                minimaxRoot(state, depth = 4)
            }
            AIDifficulty.EXPERT -> {
                // 5-ply minimax with alpha-beta and capture priority
                minimaxRoot(state, depth = 5)
            }
        }
    }

    private fun minimaxRoot(state: GameState, depth: Int): DraughtsMove {
        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, state.currentTurn)
        val aiPlayer = state.currentTurn

        // Sort moves to optimize alpha-beta pruning (captures first, then promotions)
        val sortedMoves = legalMoves.sortedByDescending { move ->
            move.captureCount * 1000 + (if (move.promotesToKing) 300 else 0)
        }

        var bestMove = sortedMoves.first()
        var bestScore = Int.MIN_VALUE + 1000
        var alpha = Int.MIN_VALUE + 100
        val beta = Int.MAX_VALUE - 100

        for (move in sortedMoves) {
            val nextState = TanzaniaDraughtsEngine.makeMove(state, move)
            val score = minimax(nextState, depth - 1, alpha, beta, isMaximizing = false, aiPlayer = aiPlayer)
            if (score > bestScore) {
                bestScore = score
                bestMove = move
            }
            alpha = max(alpha, bestScore)
            if (beta <= alpha) break
        }

        return bestMove
    }

    private fun minimax(
        state: GameState,
        depth: Int,
        alphaParam: Int,
        betaParam: Int,
        isMaximizing: Boolean,
        aiPlayer: Player
    ): Int {
        var alpha = alphaParam
        var beta = betaParam

        if (state.isGameOver) {
            return when (state.status) {
                GameStatus.PLAYER_1_WON -> if (aiPlayer == Player.PLAYER_1) 100_000 else -100_000
                GameStatus.PLAYER_2_WON -> if (aiPlayer == Player.PLAYER_2) 100_000 else -100_000
                else -> 0
            }
        }

        if (depth <= 0) {
            return evaluateBoard(state, aiPlayer)
        }

        val legalMoves = TanzaniaDraughtsEngine.getLegalMoves(state, state.currentTurn)
        if (legalMoves.isEmpty()) {
            return if (isMaximizing) -90_000 else 90_000
        }

        if (isMaximizing) {
            var maxEval = Int.MIN_VALUE + 100
            for (move in legalMoves) {
                val nextState = TanzaniaDraughtsEngine.makeMove(state, move)
                val eval = minimax(nextState, depth - 1, alpha, beta, false, aiPlayer)
                maxEval = max(maxEval, eval)
                alpha = max(alpha, eval)
                if (beta <= alpha) break
            }
            return maxEval
        } else {
            var minEval = Int.MAX_VALUE - 100
            for (move in legalMoves) {
                val nextState = TanzaniaDraughtsEngine.makeMove(state, move)
                val eval = minimax(nextState, depth - 1, alpha, beta, true, aiPlayer)
                minEval = min(minEval, eval)
                beta = min(beta, eval)
                if (beta <= alpha) break
            }
            return minEval
        }
    }

    /**
     * Heuristic evaluation function for Tanzania Draughts.
     * Evaluates material, king advantage, center square occupation,
     * advancement toward opponent back rank, and protection.
     */
    fun evaluateBoard(state: GameState, perspective: Player): Int {
        var p1Score = 0
        var p2Score = 0

        for ((pos, piece) in state.board) {
            val baseValue = if (piece.isKing) 350 else 100
            val centerBonus = centerControl[pos.row][pos.col]

            // Advancement bonus for men
            val advanceBonus = if (!piece.isKing) {
                if (piece.player == Player.PLAYER_1) {
                    (7 - pos.row) * 12 // closer to row 0
                } else {
                    pos.row * 12      // closer to row 7
                }
            } else {
                0
            }

            // Back rank defense bonus: keeping home row pieces protected early
            val defenseBonus = if (!piece.isKing) {
                if (piece.player == Player.PLAYER_1 && pos.row == 7) 15
                else if (piece.player == Player.PLAYER_2 && pos.row == 0) 15
                else 0
            } else {
                0
            }

            val totalPieceScore = baseValue + centerBonus + advanceBonus + defenseBonus

            if (piece.player == Player.PLAYER_1) {
                p1Score += totalPieceScore
            } else {
                p2Score += totalPieceScore
            }
        }

        // Mobility advantage
        val legalMovesCount = TanzaniaDraughtsEngine.getLegalMoves(state, state.currentTurn).size
        val mobilityScore = if (state.currentTurn == Player.PLAYER_1) legalMovesCount * 5 else -legalMovesCount * 5
        p1Score += mobilityScore

        return if (perspective == Player.PLAYER_1) p1Score - p2Score else p2Score - p1Score
    }
}
