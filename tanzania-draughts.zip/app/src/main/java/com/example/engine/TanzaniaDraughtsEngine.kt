package com.example.engine

import com.example.model.*

/**
 * Dedicated, authoritative rules engine for Tanzania Draughts (Dama ya Kitanzania).
 * Enforces 8x8 dark squares, mandatory captures, multi-jump sequences,
 * Tanzanian flying kings (mfalme arukaye), promotion, and win/draw conditions.
 */
object TanzaniaDraughtsEngine {

    private val ALL_DIAGONALS = listOf(
        Pair(-1, -1),
        Pair(-1, 1),
        Pair(1, -1),
        Pair(1, 1)
    )

    /**
     * Returns all legal moves for [player] in the current [state].
     * Mandatory capture is strictly enforced: if any capture exists, non-capture moves are excluded.
     */
    fun getLegalMoves(state: GameState, player: Player = state.currentTurn): List<DraughtsMove> {
        if (state.isGameOver) return emptyList()

        val allCaptures = mutableListOf<DraughtsMove>()
        for ((pos, piece) in state.board) {
            if (piece.player == player) {
                allCaptures.addAll(findCaptureMovesForPiece(state.board, pos, piece, state.rulesConfig))
            }
        }

        if (allCaptures.isNotEmpty()) {
            return when (state.rulesConfig.captureChoiceRule) {
                CaptureChoiceRule.MAXIMUM_PIECES -> {
                    val maxCount = allCaptures.maxOf { it.captureCount }
                    allCaptures.filter { it.captureCount == maxCount }
                }
                CaptureChoiceRule.FREE_CHOICE -> allCaptures
            }
        }

        // No captures available; generate ordinary moves
        val ordinaryMoves = mutableListOf<DraughtsMove>()
        for ((pos, piece) in state.board) {
            if (piece.player == player) {
                ordinaryMoves.addAll(findOrdinaryMovesForPiece(state.board, pos, piece, state.rulesConfig))
            }
        }
        return ordinaryMoves
    }

    /**
     * Returns all legal moves starting from a specific [pos].
     */
    fun getLegalMovesForPosition(state: GameState, pos: Position): List<DraughtsMove> {
        val legalMoves = getLegalMoves(state, state.currentTurn)
        return legalMoves.filter { it.from == pos }
    }

    /**
     * Determines whether any legal capture exists for [player].
     */
    fun hasCapture(state: GameState, player: Player = state.currentTurn): Boolean {
        for ((pos, piece) in state.board) {
            if (piece.player == player) {
                if (hasCaptureForPiece(state.board, pos, piece, state.rulesConfig)) {
                    return true
                }
            }
        }
        return false
    }

    private fun hasCaptureForPiece(
        board: Map<Position, DraughtsPiece>,
        pos: Position,
        piece: DraughtsPiece,
        config: RulesConfig
    ): Boolean {
        return findCaptureMovesForPiece(board, pos, piece, config).isNotEmpty()
    }

    /**
     * Find all capture sequences (including multi-step captures) for a single piece.
     */
    private fun findCaptureMovesForPiece(
        board: Map<Position, DraughtsPiece>,
        startPos: Position,
        piece: DraughtsPiece,
        config: RulesConfig
    ): List<DraughtsMove> {
        val result = mutableListOf<DraughtsMove>()
        searchCaptures(
            board = board,
            currentPos = startPos,
            originalPiece = piece,
            currentPiece = piece,
            accumulatedSteps = emptyList(),
            alreadyCaptured = emptySet(),
            config = config,
            results = result
        )
        return result
    }

    private fun searchCaptures(
        board: Map<Position, DraughtsPiece>,
        currentPos: Position,
        originalPiece: DraughtsPiece,
        currentPiece: DraughtsPiece,
        accumulatedSteps: List<MoveStep>,
        alreadyCaptured: Set<Position>,
        config: RulesConfig,
        results: MutableList<DraughtsMove>
    ) {
        val singleJumps = findSingleJumps(board, currentPos, currentPiece, alreadyCaptured, config)

        if (singleJumps.isEmpty()) {
            if (accumulatedSteps.isNotEmpty()) {
                val lastStep = accumulatedSteps.last()
                val reachesBackRank = willPromote(currentPiece, lastStep.to)
                results.add(
                    DraughtsMove(
                        steps = accumulatedSteps,
                        promotesToKing = !originalPiece.isKing && (currentPiece.isKing || reachesBackRank)
                    )
                )
            }
            return
        }

        for (jump in singleJumps) {
            val nextCaptured = alreadyCaptured + jump.capturedPos!!
            val reachesBackRank = willPromote(currentPiece, jump.to)
            val nextPiece = if (!currentPiece.isKing && reachesBackRank) {
                currentPiece.copy(type = PieceType.KING)
            } else {
                currentPiece
            }

            // In Tanzania Draughts, if a man promotes during a multi-jump and kingHaltsOnPromotion is true,
            // the turn halts immediately as a newly crowned King.
            if (!currentPiece.isKing && reachesBackRank && config.kingHaltsOnPromotion) {
                results.add(
                    DraughtsMove(
                        steps = accumulatedSteps + jump,
                        promotesToKing = true
                    )
                )
            } else {
                searchCaptures(
                    board = board,
                    currentPos = jump.to,
                    originalPiece = originalPiece,
                    currentPiece = nextPiece,
                    accumulatedSteps = accumulatedSteps + jump,
                    alreadyCaptured = nextCaptured,
                    config = config,
                    results = results
                )
            }
        }
    }

    private fun findSingleJumps(
        board: Map<Position, DraughtsPiece>,
        fromPos: Position,
        piece: DraughtsPiece,
        alreadyCaptured: Set<Position>,
        config: RulesConfig
    ): List<MoveStep> {
        val jumps = mutableListOf<MoveStep>()
        val opponent = piece.player.opponent()

        if (!piece.isKing) {
            // Ordinary Man capture
            val forwardRowDelta = if (piece.player == Player.PLAYER_1) -1 else 1
            val directions = mutableListOf(Pair(forwardRowDelta, -1), Pair(forwardRowDelta, 1))

            if (config.menCanCaptureBackward) {
                directions.add(Pair(-forwardRowDelta, -1))
                directions.add(Pair(-forwardRowDelta, 1))
            }

            for ((dr, dc) in directions) {
                val midPos = Position(fromPos.row + dr, fromPos.col + dc)
                val landPos = Position(fromPos.row + 2 * dr, fromPos.col + 2 * dc)

                if (landPos.isValid) {
                    val midPiece = board[midPos]
                    val isMidCaptured = midPos in alreadyCaptured
                    val isLandingOccupied = (board.containsKey(landPos) && landPos !in alreadyCaptured)

                    if (midPiece != null && midPiece.player == opponent && !isMidCaptured && !isLandingOccupied) {
                        jumps.add(MoveStep(from = fromPos, to = landPos, capturedPos = midPos))
                    }
                }
            }
        } else {
            // Flying King (Mfalme arukaye)
            // Can fly along 4 diagonals, hop over an opponent piece with empty space before and after
            for ((dr, dc) in ALL_DIAGONALS) {
                var step = 1
                var foundOpponent: Position? = null

                while (true) {
                    val checkPos = Position(fromPos.row + dr * step, fromPos.col + dc * step)
                    if (!checkPos.isValid) break

                    val pieceHere = board[checkPos]
                    val isAlreadyCaptured = checkPos in alreadyCaptured

                    if (foundOpponent == null) {
                        if (pieceHere == null || isAlreadyCaptured) {
                            // Empty square before piece, keep sliding
                            step++
                            continue
                        } else if (pieceHere.player == opponent) {
                            // First piece encountered is opponent!
                            foundOpponent = checkPos
                            step++
                        } else {
                            // Encountered own piece, ray is blocked
                            break
                        }
                    } else {
                        // We already hopped over an opponent piece.
                        // Every subsequent contiguous empty square is a legal landing square!
                        if (pieceHere == null || isAlreadyCaptured) {
                            jumps.add(MoveStep(from = fromPos, to = checkPos, capturedPos = foundOpponent))
                            step++
                        } else {
                            // Blocked by another piece
                            break
                        }
                    }
                }
            }
        }

        return jumps
    }

    private fun findOrdinaryMovesForPiece(
        board: Map<Position, DraughtsPiece>,
        fromPos: Position,
        piece: DraughtsPiece,
        @Suppress("UNUSED_PARAMETER") config: RulesConfig
    ): List<DraughtsMove> {
        val moves = mutableListOf<DraughtsMove>()

        if (!piece.isKing) {
            val forwardRowDelta = if (piece.player == Player.PLAYER_1) -1 else 1
            for (dc in listOf(-1, 1)) {
                val targetPos = Position(fromPos.row + forwardRowDelta, fromPos.col + dc)
                if (targetPos.isValid && !board.containsKey(targetPos)) {
                    val promotes = willPromote(piece, targetPos)
                    moves.add(
                        DraughtsMove(
                            steps = listOf(MoveStep(from = fromPos, to = targetPos)),
                            promotesToKing = promotes
                        )
                    )
                }
            }
        } else {
            // Flying King slides along any diagonal until blocked
            for ((dr, dc) in ALL_DIAGONALS) {
                var step = 1
                while (true) {
                    val targetPos = Position(fromPos.row + dr * step, fromPos.col + dc * step)
                    if (!targetPos.isValid || board.containsKey(targetPos)) break

                    moves.add(
                        DraughtsMove(
                            steps = listOf(MoveStep(from = fromPos, to = targetPos)),
                            promotesToKing = false
                        )
                    )
                    step++
                }
            }
        }

        return moves
    }

    private fun willPromote(piece: DraughtsPiece, targetPos: Position): Boolean {
        if (piece.isKing) return false
        return (piece.player == Player.PLAYER_1 && targetPos.row == 0) ||
               (piece.player == Player.PLAYER_2 && targetPos.row == 7)
    }

    /**
     * Executes a legal move on [state], returning the updated [GameState].
     * Enforces move legality, captures removal, king promotion, and updates game status.
     */
    fun makeMove(state: GameState, move: DraughtsMove): GameState {
        val currentTurn = state.currentTurn
        val movingPiece = state.board[move.from]
            ?: throw IllegalArgumentException("No piece at ${move.from}")

        require(movingPiece.player == currentTurn) { "Cannot move opponent's piece" }

        val newBoard = state.board.toMutableMap()
        newBoard.remove(move.from)

        // Remove all captured pieces
        for (capPos in move.capturedPositions) {
            newBoard.remove(capPos)
        }

        // Check king promotion
        val willBeKing = movingPiece.isKing || move.promotesToKing || willPromote(movingPiece, move.to)
        val finalPiece = if (willBeKing) movingPiece.copy(type = PieceType.KING) else movingPiece
        newBoard[move.to] = finalPiece

        val newCapturedP1 = if (currentTurn == Player.PLAYER_1) state.capturedByP1 + move.captureCount else state.capturedByP1
        val newCapturedP2 = if (currentTurn == Player.PLAYER_2) state.capturedByP2 + move.captureCount else state.capturedByP2

        val newHalfMoveClock = if (move.isCapture || !movingPiece.isKing) 0 else state.halfMoveClockWithoutCapture + 1

        val nextPlayer = currentTurn.opponent()
        val nextStateCandidate = state.copy(
            board = newBoard,
            currentTurn = nextPlayer,
            moveHistory = state.moveHistory + move,
            halfMoveClockWithoutCapture = newHalfMoveClock,
            capturedByP1 = newCapturedP1,
            capturedByP2 = newCapturedP2,
            selectedPosition = null,
            activeMultiStepMove = null
        )

        // Check game over conditions
        val nextPlayerPieces = nextStateCandidate.countPieces(nextPlayer)
        if (nextPlayerPieces == 0) {
            return nextStateCandidate.copy(
                status = if (currentTurn == Player.PLAYER_1) GameStatus.PLAYER_1_WON else GameStatus.PLAYER_2_WON
            )
        }

        val nextLegalMoves = getLegalMoves(nextStateCandidate, nextPlayer)
        if (nextLegalMoves.isEmpty()) {
            // Opponent is blocked!
            return nextStateCandidate.copy(
                status = if (currentTurn == Player.PLAYER_1) GameStatus.PLAYER_1_WON else GameStatus.PLAYER_2_WON
            )
        }

        if (newHalfMoveClock >= state.rulesConfig.maxMovesWithoutCapture * 2) {
            return nextStateCandidate.copy(status = GameStatus.DRAW_MOVE_LIMIT)
        }

        return nextStateCandidate
    }
}
