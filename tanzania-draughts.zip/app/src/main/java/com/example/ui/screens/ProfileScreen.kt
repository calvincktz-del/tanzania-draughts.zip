package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.MatchRecord
import com.example.model.PlayerProfile
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    profile: PlayerProfile,
    matchHistory: List<MatchRecord>,
    language: AppLanguage,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI
    var selectedReplayMatch by remember { mutableStateOf<MatchRecord?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("profile_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_profile_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) "Wasifu wa Mchezaji" else "Player Profile",
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${profile.accountStatus} • ${profile.registrationDate}",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Profile Card Header
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGreenPrimary, TzGoldAccent)))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .clip(CircleShape)
                                .background(Brush.radialGradient(listOf(TzGreenPrimary, TzGreenDark)))
                                .border(3.dp, TzGoldAccent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = profile.avatarEmoji, fontSize = 36.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = profile.displayName,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "${profile.region} • @${profile.username}",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Division & Rating Badges
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = TzGoldAccent.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "Elo: ${profile.skillRating}",
                                    color = TzGoldAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = TzGreenPrimary
                            ) {
                                Text(
                                    text = profile.division,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // XP Level Progress Bar
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Ngazi ya ${profile.level} (Level ${profile.level})",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${profile.xp} / ${profile.nextLevelXp} XP",
                                    color = TzGoldAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { (profile.xp.toFloat() / profile.nextLevelXp).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = TzGoldAccent,
                                trackColor = TzDarkSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Performance Statistics Grid
            item {
                Text(
                    text = if (isSw) "TAKWIMU ZA MCHEZO" else "CAREER STATISTICS",
                    color = TzGoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(title = if (isSw) "Mechi" else "Played", value = "${profile.matchesPlayed}", modifier = Modifier.weight(1f))
                    StatCard(title = if (isSw) "Ushindi" else "Wins", value = "${profile.wins}", color = Color(0xFF81C784), modifier = Modifier.weight(1f))
                    StatCard(title = if (isSw) "Sare" else "Draws", value = "${profile.draws}", color = Color(0xFFFFB74D), modifier = Modifier.weight(1f))
                    StatCard(title = if (isSw) "Kushindwa" else "Losses", value = "${profile.losses}", color = Color(0xFFFF5252), modifier = Modifier.weight(1f))
                    StatCard(title = "Win %", value = "${profile.winRate}%", color = TzGoldAccent, modifier = Modifier.weight(1f))
                }
            }

            // Achievements
            item {
                Text(
                    text = if (isSw) "MATAJI NA MAFANIKIO (ACHIEVEMENTS)" else "TROPHIES & ACHIEVEMENTS",
                    color = TzGoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    profile.achievements.forEach { ach ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (ach.isUnlocked) TzDarkCard else TzDarkCard.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ach.iconEmoji,
                                    fontSize = 24.sp,
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isSw) ach.titleSw else ach.titleEn,
                                        color = if (ach.isUnlocked) Color.White else Color.White.copy(alpha = 0.5f),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = if (isSw) ach.descriptionSw else ach.descriptionEn,
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 11.sp
                                    )
                                }
                                if (ach.isUnlocked) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(18.dp))
                                } else {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Match History with Replay Viewer
            item {
                Text(
                    text = if (isSw) "HISTORIA YA MECHI NA REPLAY" else "MATCH HISTORY & REPLAY",
                    color = TzGoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            items(matchHistory) { record ->
                val isWin = record.result == "WIN"
                val isDraw = record.result == "DRAW"

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "dhidi ya ${record.opponentName}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${record.mode} • ${record.date}",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isWin) TzGreenPrimary else if (isDraw) Color(0xFFE65100) else Color(0xFFB71C1C)
                            ) {
                                Text(
                                    text = record.result,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = { selectedReplayMatch = record },
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(TzDarkSurfaceVariant, CircleShape)
                            ) {
                                Icon(Icons.Default.PlayCircle, contentDescription = "Replay", tint = TzGoldAccent, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Match Replay Dialog
    if (selectedReplayMatch != null) {
        val record = selectedReplayMatch!!
        AlertDialog(
            onDismissRequest = { selectedReplayMatch = null },
            containerColor = TzDarkCard,
            title = {
                Text(
                    text = if (isSw) "Kumbukumbu ya Mchezo (${record.result})" else "Match Notation Record (${record.result})",
                    color = TzGoldAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Mpinzani: ${record.opponentName} • ${record.date}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isSw) "Miondoko ya Kete (Move Notation):" else "Move Sequences:",
                        color = TzGoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = TzDarkSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = record.notationMoves.joinToString("  "),
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedReplayMatch = null },
                    colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black)
                ) {
                    Text("Funga (Close)", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    color: Color = Color.White,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = TzDarkCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text(text = title, color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
        }
    }
}
