package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DraughtsRepository
import com.example.engine.AIDifficulty
import com.example.model.*
import com.example.ui.screens.*
import com.example.ui.theme.TanzaniaDraughtsTheme

enum class AppScreen {
    SPLASH,
    HOME,
    GAME_AI,
    GAME_LOCAL,
    GAME_PRACTICE,
    GAME_ONLINE,
    ONLINE_LOBBY,
    LEAGUES,
    TOURNAMENTS,
    PROFILE,
    RULES,
    ADMIN,
    LEGAL,
    SETTINGS
}

@Composable
fun DraughtsApp(
    repository: DraughtsRepository = remember { DraughtsRepository() }
) {
    val language by repository.language.collectAsStateWithLifecycle()
    val boardTheme by repository.boardTheme.collectAsStateWithLifecycle()
    val rulesConfig by repository.rulesConfig.collectAsStateWithLifecycle()
    val profile by repository.profile.collectAsStateWithLifecycle()
    val leagues by repository.leagues.collectAsStateWithLifecycle()
    val standings by repository.standings.collectAsStateWithLifecycle()
    val fixtures by repository.fixtures.collectAsStateWithLifecycle()
    val tournament by repository.tournament.collectAsStateWithLifecycle()
    val matchHistory by repository.matchHistory.collectAsStateWithLifecycle()
    val disputes by repository.disputes.collectAsStateWithLifecycle()
    val auditLogs by repository.auditLogs.collectAsStateWithLifecycle()
    val isAdmin by repository.isAdmin.collectAsStateWithLifecycle()

    var navigationStack by remember { mutableStateOf(listOf(AppScreen.SPLASH)) }
    val currentScreen = navigationStack.last()

    fun navigateTo(screen: AppScreen) {
        navigationStack = navigationStack + screen
    }

    fun navigateBack() {
        if (navigationStack.size > 1) {
            navigationStack = navigationStack.dropLast(1)
        }
    }

    fun navigateHome() {
        navigationStack = listOf(AppScreen.HOME)
    }

    TanzaniaDraughtsTheme(darkTheme = true) {
        Surface(modifier = Modifier.fillMaxSize()) {
            when (currentScreen) {
                AppScreen.SPLASH -> {
                    SplashScreen(
                        language = language,
                        onToggleLanguage = { repository.toggleLanguage() },
                        onStartGame = { navigateHome() },
                        onOpenRules = { navigateTo(AppScreen.RULES) }
                    )
                }

                AppScreen.HOME -> {
                    HomeScreen(
                        profile = profile,
                        language = language,
                        onStartAI = { navigateTo(AppScreen.GAME_AI) },
                        onStartLocal2P = { navigateTo(AppScreen.GAME_LOCAL) },
                        onStartOnline = { navigateTo(AppScreen.ONLINE_LOBBY) },
                        onStartPractice = { navigateTo(AppScreen.GAME_PRACTICE) },
                        onNavigateLeagues = { navigateTo(AppScreen.LEAGUES) },
                        onNavigateTournaments = { navigateTo(AppScreen.TOURNAMENTS) },
                        onNavigateProfile = { navigateTo(AppScreen.PROFILE) },
                        onNavigateRules = { navigateTo(AppScreen.RULES) },
                        onNavigateSettings = { navigateTo(AppScreen.SETTINGS) },
                        onNavigateAdmin = { navigateTo(AppScreen.ADMIN) }
                    )
                }

                AppScreen.GAME_AI -> {
                    BackHandler { navigateBack() }
                    GameScreen(
                        mode = PlayMode.AI,
                        initialDifficulty = AIDifficulty.MEDIUM,
                        boardTheme = boardTheme,
                        language = language,
                        onBackToHome = { navigateBack() },
                        onRecordResult = { res, opp, rat, moves ->
                            repository.recordGameResult(res, opp, rat, moves)
                        }
                    )
                }

                AppScreen.GAME_LOCAL -> {
                    BackHandler { navigateBack() }
                    GameScreen(
                        mode = PlayMode.LOCAL_2P,
                        boardTheme = boardTheme,
                        language = language,
                        onBackToHome = { navigateBack() },
                        onRecordResult = { res, opp, rat, moves ->
                            repository.recordGameResult(res, opp, rat, moves)
                        }
                    )
                }

                AppScreen.GAME_PRACTICE -> {
                    BackHandler { navigateBack() }
                    GameScreen(
                        mode = PlayMode.PRACTICE,
                        boardTheme = boardTheme,
                        language = language,
                        onBackToHome = { navigateBack() },
                        onRecordResult = { _, _, _, _ -> }
                    )
                }

                AppScreen.GAME_ONLINE -> {
                    BackHandler { navigateBack() }
                    GameScreen(
                        mode = PlayMode.ONLINE,
                        boardTheme = boardTheme,
                        language = language,
                        onBackToHome = { navigateBack() },
                        onRecordResult = { res, opp, rat, moves ->
                            repository.recordGameResult(res, opp, rat, moves)
                        }
                    )
                }

                AppScreen.ONLINE_LOBBY -> {
                    BackHandler { navigateBack() }
                    OnlineMatchScreen(
                        profile = profile,
                        language = language,
                        onStartOnlineGame = {
                            navigateTo(AppScreen.GAME_ONLINE)
                        },
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.LEAGUES -> {
                    BackHandler { navigateBack() }
                    LeagueScreen(
                        leagues = leagues,
                        standings = standings,
                        fixtures = fixtures,
                        language = language,
                        onRegisterLeague = { repository.registerForLeague(it) },
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.TOURNAMENTS -> {
                    BackHandler { navigateBack() }
                    TournamentScreen(
                        tournament = tournament,
                        language = language,
                        onPlayTournamentMatch = {
                            navigateTo(AppScreen.GAME_AI)
                        },
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.PROFILE -> {
                    BackHandler { navigateBack() }
                    ProfileScreen(
                        profile = profile,
                        matchHistory = matchHistory,
                        language = language,
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.RULES -> {
                    BackHandler { navigateBack() }
                    RulesScreen(
                        language = language,
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.ADMIN -> {
                    BackHandler { navigateBack() }
                    AdminScreen(
                        rulesConfig = rulesConfig,
                        disputes = disputes,
                        auditLogs = auditLogs,
                        isAdmin = isAdmin,
                        language = language,
                        onToggleAdmin = { repository.toggleAdminMode() },
                        onUpdateRulesConfig = { repository.updateRulesConfig(it) },
                        onGenerateFixtures = { repository.generateNewFixtures() },
                        onResolveDispute = { id, text, approved ->
                            repository.resolveDispute(id, text, approved)
                        },
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.LEGAL -> {
                    BackHandler { navigateBack() }
                    LegalScreen(
                        language = language,
                        onBack = { navigateBack() }
                    )
                }

                AppScreen.SETTINGS -> {
                    BackHandler { navigateBack() }
                    SettingsScreen(
                        currentLanguage = language,
                        currentBoardTheme = boardTheme,
                        onSelectLanguage = { repository.setLanguage(it) },
                        onSelectBoardTheme = { repository.setBoardTheme(it) },
                        onNavigateLegal = { navigateTo(AppScreen.LEGAL) },
                        onBack = { navigateBack() }
                    )
                }
            }
        }
    }
}
