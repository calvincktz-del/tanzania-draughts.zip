package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.PlayerProfile
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OnlineMatchScreen(
    profile: PlayerProfile,
    language: AppLanguage,
    onStartOnlineGame: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI
    val coroutineScope = rememberCoroutineScope()

    var isSearchingMatch by remember { mutableStateOf(false) }
    var searchTimer by remember { mutableStateOf(0) }
    var createdRoomCode by remember { mutableStateOf<String?>(null) }
    var inputRoomCode by remember { mutableStateOf("") }
    var showJoinDialog by remember { mutableStateOf(false) }
    var selectedQueueType by remember { mutableStateOf("RANKED") } // "RANKED" or "QUICK"

    // Simulate matchmaking search
    LaunchedEffect(isSearchingMatch) {
        if (isSearchingMatch) {
            searchTimer = 0
            while (isSearchingMatch && searchTimer < 3) {
                delay(1000)
                searchTimer++
            }
            if (isSearchingMatch) {
                isSearchingMatch = false
                onStartOnlineGame()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("online_match_screen")
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_online_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) "Mechi za Mtandaoni (Multiplayer)" else "Online Multiplayer",
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "Seva ya Dar es Salaam: Mtandaoni 🟢 (24ms)" else "Dar es Salaam Server: Online 🟢 (24ms)",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        if (isSearchingMatch) {
            // Matchmaking radar / searching UI
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val infiniteTransition = rememberInfiniteTransition(label = "radar")
                    val radarScale by infiniteTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 1.35f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1200, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "scale"
                    )

                    Box(
                        modifier = Modifier
                            .size((120 * radarScale).dp)
                            .clip(CircleShape)
                            .border(2.dp, TzGoldAccent.copy(alpha = 0.5f), CircleShape)
                            .background(TzGreenPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "👑", fontSize = 42.sp)
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = if (isSw) "Inatafuta Mpinzani Mtandaoni..." else "Searching for Opponent...",
                        color = TzGoldAccent,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isSw) "Mechi ya Viwango (Elo: ${profile.skillRating}) • 00:0$searchTimer" else "Ranked Match (Elo: ${profile.skillRating}) • 00:0$searchTimer",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    OutlinedButton(
                        onClick = { isSearchingMatch = false },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isSw) "Ghairi Utafutaji" else "Cancel Queue")
                    }
                }
            }
        } else {
            // Main Online Lobby Options
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Elo Rating Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGreenPrimary, TzGoldAccent)))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isSw) "Kiwango Chako cha Ushindani" else "Your Competitive Rating",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Elo ${profile.skillRating} • ${profile.division}",
                                color = TzGoldAccent,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TzGreenPrimary
                        ) {
                            Text(
                                text = "${profile.winRate}% Win",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Ranked Matchmaking Button
                Button(
                    onClick = {
                        selectedQueueType = "RANKED"
                        isSearchingMatch = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .testTag("btn_find_ranked_match"),
                    colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isSw) "TAFUTA MECHI YA VIWANGO (RANKED)" else "FIND RANKED MATCH",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (isSw) "Pata alama za Elo (+15 / -10) • Sheria za Tanzania" else "Gain Elo points (+15 / -10) • Tanzania Rules",
                            fontSize = 10.sp,
                            color = Color.Black.copy(alpha = 0.8f)
                        )
                    }
                }

                // Quick Match Button
                OutlinedButton(
                    onClick = {
                        selectedQueueType = "QUICK"
                        isSearchingMatch = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btn_quick_match"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(TzGreenLight, TzSkyBlue))),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSw) "Mechi ya Haraka (Quick Casual Match)" else "Quick Casual Match",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Divider(color = TzDarkSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))

                // Private Room Section
                Text(
                    text = if (isSw) "CHUMBA CHA BINAFSI NA RAFIKI" else "PRIVATE ROOM & INVITE CODE",
                    color = TzGoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )

                if (createdRoomCode != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = TzGreenDark)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (isSw) "Msimbo Wako wa Chumba:" else "Your Room Invite Code:",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = createdRoomCode!!,
                                color = TzGoldAccent,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isSw) "Mpatie rafiki yako msimbo huu ajiunge na mechi" else "Share this code with your friend to connect",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onStartOnlineGame,
                                colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (isSw) "Ingia Chumbani" else "Enter Game", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val randomDigits = (1000..9999).random()
                                createdRoomCode = "TZ-$randomDigits"
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("btn_create_room"),
                            colors = ButtonDefaults.buttonColors(containerColor = TzDarkSurfaceVariant, contentColor = TzGoldAccent),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isSw) "Unda Chumba" else "Create Room", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showJoinDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("btn_join_room"),
                            colors = ButtonDefaults.buttonColors(containerColor = TzDarkSurfaceVariant, contentColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isSw) "Jiunge kwa Msimbo" else "Join by Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Security & Anti-cheating footnote
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = TzDarkSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isSw) "Ulinzi wa Mchezo: Miondoko yote ya mtandaoni inahakikiwa na injini ya TanzaniaDraughtsEngine kuzuia kubadilisha kete au kuruka kula kwa lazima." else "Fair Play Protection: All moves are verified against TanzaniaDraughtsEngine to prevent illegal moves or skipping captures.",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }

    // Join Room Dialog
    if (showJoinDialog) {
        AlertDialog(
            onDismissRequest = { showJoinDialog = false },
            containerColor = TzDarkCard,
            title = {
                Text(
                    text = if (isSw) "Weka Msimbo wa Chumba" else "Enter Room Code",
                    color = TzGoldAccent,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = if (isSw) "Mfano: TZ-4821" else "Example: TZ-4821",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = inputRoomCode,
                        onValueChange = { inputRoomCode = it.uppercase() },
                        singleLine = true,
                        placeholder = { Text("TZ-XXXX") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = TzGoldAccent,
                            unfocusedBorderColor = TzDarkSurfaceVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputRoomCode.isNotBlank()) {
                            showJoinDialog = false
                            onStartOnlineGame()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black)
                ) {
                    Text(if (isSw) "Jiunge na Mechi" else "Connect", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showJoinDialog = false }) {
                    Text(if (isSw) "Ghairi" else "Cancel", color = Color.White)
                }
            }
        )
    }
}
