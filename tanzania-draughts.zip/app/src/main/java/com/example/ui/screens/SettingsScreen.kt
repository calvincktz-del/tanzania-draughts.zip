package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.BoardThemeStyle
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    currentLanguage: AppLanguage,
    currentBoardTheme: BoardThemeStyle,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectBoardTheme: (BoardThemeStyle) -> Unit,
    onNavigateLegal: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = currentLanguage == AppLanguage.SWAHILI
    var soundEnabled by remember { mutableStateOf(true) }
    var hapticsEnabled by remember { mutableStateOf(true) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var accountDeletedNotice by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("settings_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_settings_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) "Mipangilio na Faragha" else "Settings & Privacy",
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "Lugha, Mandhari na Usalama wa Data" else "Language, Themes & Data Protection",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Language Selection
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isSw) "Lugha ya Programu (Language)" else "App Language",
                            color = TzGoldAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilterChip(
                                selected = currentLanguage == AppLanguage.SWAHILI,
                                onClick = { onSelectLanguage(AppLanguage.SWAHILI) },
                                label = { Text("Kiswahili 🇹🇿", fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TzGreenPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            FilterChip(
                                selected = currentLanguage == AppLanguage.ENGLISH,
                                onClick = { onSelectLanguage(AppLanguage.ENGLISH) },
                                label = { Text("English 🌐", fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TzGreenPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Board Themes
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isSw) "Mandhari ya Ubao wa Dama (Board Themes)" else "Draughts Board Themes",
                            color = TzGoldAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            BoardThemeStyle.values().forEach { theme ->
                                val isSelected = currentBoardTheme == theme
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) TzDarkSurfaceVariant else Color.Transparent)
                                        .border(
                                            width = if (isSelected) 1.5.dp else 0.dp,
                                            color = if (isSelected) TzGoldAccent else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { onSelectBoardTheme(theme) }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Color preview squares
                                        Row(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                        ) {
                                            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(theme.lightSquareHex)))
                                            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(theme.darkSquareHex)))
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Text(
                                            text = if (isSw) theme.titleSw else theme.titleEn,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }

                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Audio & Feedback
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isSw) "Sauti na Mtetemo" else "Audio & Haptic Feedback",
                            color = TzGoldAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = if (isSw) "Sauti za Kete na Ubao" else "Piece Move & Capture Sounds", color = Color.White, fontSize = 13.sp)
                            Switch(
                                checked = soundEnabled,
                                onCheckedChange = { soundEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = TzGoldAccent, checkedTrackColor = TzGreenPrimary)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = if (isSw) "Mtetemo Wakati wa Kula Kete" else "Haptic Vibration on Capture", color = Color.White, fontSize = 13.sp)
                            Switch(
                                checked = hapticsEnabled,
                                onCheckedChange = { hapticsEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = TzGoldAccent, checkedTrackColor = TzGreenPrimary)
                            )
                        }
                    }
                }
            }

            // Legal Hub Navigation Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateLegal() }
                        .testTag("btn_settings_legal"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Gavel, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isSw) "Vigezo na Sheria za Tanzania" else "Legal & Regulatory Compliance",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isSw) "PDPA 2022, Gaming Act Cap 41, Sera ya Faragha" else "PDPA 2022, Gaming Act Cap 41, Terms",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.White.copy(alpha = 0.5f))
                    }
                }
            }

            // Account Deletion under PDPA 2022
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1515))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isSw) "Haki ya Kufuta Data (PDPA 2022)" else "Data Deletion (PDPA 2022 Right)",
                            color = Color(0xFFFF5252),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isSw) "Kulingana na Sheria ya Ulinzi wa Taarifa Binafsi, unayo haki ya kuomba akaunti na takwimu zako zote zifutwe kabisa kwenye mfumo." else "Under the Personal Data Protection Act 2022, you may request permanent erasure of your account and competitive records.",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { showDeleteAccountDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(Color(0xFFFF5252), Color(0xFFD32F2F)))),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_delete_account")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isSw) "Futa Akaunti Yangu Kabisa" else "Permanently Delete Account", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Account Deletion Confirmation Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            containerColor = TzDarkCard,
            title = {
                Text(
                    text = if (isSw) "Thibitisha Kufuta Akaunti" else "Confirm Permanent Deletion",
                    color = Color(0xFFFF5252),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isSw) "Je, una uhakika unataka kufuta akaunti yako na historia yote ya mechi? Kitendo hiki hakiwezi kurudishwa nyuma kwa mujibu wa PDPA 2022." else "Are you sure you want to permanently delete your profile, ranking, and match history? This action is irreversible pursuant to PDPA 2022.",
                    color = Color.White,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountDialog = false
                        accountDeletedNotice = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252), contentColor = Color.White)
                ) {
                    Text(if (isSw) "Ndio, Futa Kabisa" else "Yes, Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteAccountDialog = false }) {
                    Text(if (isSw) "Ghairi" else "Cancel", color = Color.White)
                }
            }
        )
    }

    if (accountDeletedNotice) {
        AlertDialog(
            onDismissRequest = { accountDeletedNotice = false },
            containerColor = TzDarkCard,
            title = { Text(if (isSw) "Ombi Limetekelezwa" else "Request Executed", color = TzGoldAccent) },
            text = {
                Text(
                    text = if (isSw) "Taarifa zako zimefutwa kikamilifu kutoka kwenye kumbukumbu ya simu na mfumo." else "Your personal records have been securely purged from the system.",
                    color = Color.White
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        accountDeletedNotice = false
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black)
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
