package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun AdminScreen(
    rulesConfig: RulesConfig,
    disputes: List<DisputeReport>,
    auditLogs: List<AuditLog>,
    isAdmin: Boolean,
    language: AppLanguage,
    onToggleAdmin: () -> Unit,
    onUpdateRulesConfig: (RulesConfig) -> Unit,
    onGenerateFixtures: () -> Unit,
    onResolveDispute: (reportId: String, text: String, approved: Boolean) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI
    var selectedDisputeForAction by remember { mutableStateOf<DisputeReport?>(null) }
    var resolutionText by remember { mutableStateOf("") }
    var showSnackbar by remember { mutableStateOf(false) }
    var snackbarMsg by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("admin_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .background(TzDarkSurfaceVariant, CircleShape)
                        .testTag("btn_admin_back")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (isSw) "Dashibodi ya Msimamizi (Admin)" else "League Administrator Dashboard",
                        color = TzGoldAccent,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isSw) "Usimamizi wa Ligi, Sheria na Migogoro" else "League, Rules & Dispute Management",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp
                    )
                }
            }

            // Admin Role Badge & Toggle
            FilledTonalButton(
                onClick = onToggleAdmin,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = if (isAdmin) TzGreenPrimary else TzDarkSurfaceVariant,
                    contentColor = if (isAdmin) Color.White else TzGoldAccent
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isAdmin) "Admin ON" else "Admin OFF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Notice
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = TzGreenDark,
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzGreenLight)))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isSw) "Vitendo vyote vya kiutawala vinarekodiwa kwenye daftari la ukaguzi (Audit Log) kwa uwazi na uadilifu." else "All administrator actions are logged into the audit trail for transparency and governance.",
                            color = Color.White,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // Rules Configuration Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isSw) "Kanuni za Ligi (Rules Profile)" else "League Rules Profile",
                                color = TzGoldAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(shape = RoundedCornerShape(4.dp), color = TzGreenPrimary) {
                                Text(
                                    text = rulesConfig.rulesetVersion,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Capture choice toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isSw) "Uchaguzi wa Kula Kete" else "Capture Path Choice",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (rulesConfig.captureChoiceRule == CaptureChoiceRule.FREE_CHOICE) {
                                        if (isSw) "Uhuru wa Kuchagua (Free Choice)" else "Free choice between legal capture paths"
                                    } else {
                                        if (isSw) "Kula Kete Nyingi Zaidi (Maximum Pieces)" else "Must take path with most captures"
                                    },
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 10.sp
                                )
                            }

                            Switch(
                                checked = rulesConfig.captureChoiceRule == CaptureChoiceRule.MAXIMUM_PIECES,
                                onCheckedChange = { checked ->
                                    val newRule = if (checked) CaptureChoiceRule.MAXIMUM_PIECES else CaptureChoiceRule.FREE_CHOICE
                                    onUpdateRulesConfig(rulesConfig.copy(captureChoiceRule = newRule))
                                    snackbarMsg = if (isSw) "Kanuni ya Kula Kete imesasishwa!" else "Capture rule updated!"
                                    showSnackbar = true
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TzGoldAccent,
                                    checkedTrackColor = TzGreenPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Men backward capture toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isSw) "Kete ya Kawaida Kula Nyuma" else "Men Backward Capture",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (rulesConfig.menCanCaptureBackward) {
                                        if (isSw) "Inaruhusiwa kula nyuma" else "Allowed"
                                    } else {
                                        if (isSw) "Chaguo-msingi Tanzania: Kula Mbele Pekee" else "Default Tanzania: Forward Only"
                                    },
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 10.sp
                                )
                            }

                            Switch(
                                checked = rulesConfig.menCanCaptureBackward,
                                onCheckedChange = { checked ->
                                    onUpdateRulesConfig(rulesConfig.copy(menCanCaptureBackward = checked))
                                    snackbarMsg = if (isSw) "Kanuni ya kete imesasishwa!" else "Rules updated!"
                                    showSnackbar = true
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TzGoldAccent,
                                    checkedTrackColor = TzGreenPrimary
                                )
                            )
                        }
                    }
                }
            }

            // Fixture Generation Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isSw) "Zalisha Ratiba ya Mzunguko Unaofuata" else "Generate Next Round Fixtures",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isSw) "Unda mechi za mzunguko bila kurudia washiriki" else "Automated round-robin pairing without duplicates",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = {
                                onGenerateFixtures()
                                snackbarMsg = if (isSw) "Ratiba mpya imezalishwa!" else "New fixtures generated!"
                                showSnackbar = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isSw) "Zalisha" else "Generate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Disputes Review Section
            item {
                Text(
                    text = if (isSw) "MALALAMIKO NA MIGOGORO YA MECHI" else "DISPUTES & APPEALS",
                    color = TzGoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            items(disputes) { disp ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${disp.reportId} • ${disp.category}",
                                color = TzGoldAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (disp.status.contains("Resolved")) TzGreenPrimary else Color(0xFFE65100)
                            ) {
                                Text(
                                    text = disp.status,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Mtoa Malalamiko: ${disp.reporterName} • Mechi: ${disp.matchId}",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )

                        Text(
                            text = disp.description,
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        if (disp.adminResolution != null) {
                            Text(
                                text = "Uamuzi wa Admin: ${disp.adminResolution}",
                                color = Color(0xFF81C784),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = {
                                        selectedDisputeForAction = disp
                                        resolutionText = ""
                                    },
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = TzGreenPrimary, contentColor = Color.White)
                                ) {
                                    Text(if (isSw) "Kagua & Toa Uamuzi" else "Review & Decide", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Audit Logs Section
            item {
                Text(
                    text = if (isSw) "DAFTARI LA UKAGUZI LA KIUTAWALA (AUDIT LOGS)" else "ADMINISTRATIVE AUDIT LOG",
                    color = TzGoldAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            items(auditLogs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkSurfaceVariant.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.History, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "[${log.action}] ${log.target}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${log.actor} (${log.role}) • ${log.timestamp}",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Dispute Resolution Modal
    if (selectedDisputeForAction != null) {
        val disp = selectedDisputeForAction!!
        AlertDialog(
            onDismissRequest = { selectedDisputeForAction = null },
            containerColor = TzDarkCard,
            title = {
                Text(
                    text = if (isSw) "Uamuzi wa Mgogoro: ${disp.reportId}" else "Dispute Resolution: ${disp.reportId}",
                    color = TzGoldAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Maelezo: ${disp.description}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = resolutionText,
                        onValueChange = { resolutionText = it },
                        placeholder = { Text(if (isSw) "Andika sababu ya uamuzi..." else "Enter reasoned decision...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = TzGoldAccent,
                            unfocusedBorderColor = TzDarkSurfaceVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val text = resolutionText.ifBlank { "Uamuzi umetolewa kwa kuzingatia kanuni za TDL-2024.1." }
                        onResolveDispute(disp.reportId, text, true)
                        selectedDisputeForAction = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black)
                ) {
                    Text(if (isSw) "Thibitisha" else "Approve", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        val text = resolutionText.ifBlank { "Malalamiko yametupiliwa mbali kwa ukosefu wa ushahidi." }
                        onResolveDispute(disp.reportId, text, false)
                        selectedDisputeForAction = null
                    }
                ) {
                    Text(if (isSw) "Tupilia Mbali" else "Dismiss", color = Color(0xFFFF5252))
                }
            }
        )
    }
}
