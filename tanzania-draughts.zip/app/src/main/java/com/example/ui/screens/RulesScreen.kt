package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.*

@Composable
fun RulesScreen(
    language: AppLanguage,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("rules_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_rules_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) "Sheria Rasmi za Rasimu ya Tanzania" else "Official Tanzania Draughts Rules",
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "Mwongozo wa Ligi Kuu (TDL-2024.1)" else "League Code (TDL-2024.1)",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                RuleItemCard(
                    title = if (isSw) "1. Ubao na Kuanza (Board Setup)" else "1. Board & Starting Setup",
                    content = if (isSw) {
                        "Mchezo unachezwa kwenye ubao wa 8x8 (miraba 64). Kete zote hutembea na kucheza kwenye miraba 32 ya giza pekee.\n\nKila mchezaji anaanza na kete 12 zilizowekwa kwenye safu tatu za mwanzo kwenye upande wake (safu 0-2 kwa Mchezaji 2 na safu 5-7 kwa Mchezaji 1). Safu mbili za katikati (3 na 4) zinabaki tupu."
                    } else {
                        "Played on an 8x8 board (64 squares). All pieces play strictly on the 32 dark squares.\n\nEach player begins with 12 pieces placed on their first three playable rows (rows 0-2 for Player 2 and rows 5-7 for Player 1). The middle two rows remain empty."
                    }
                )
            }

            item {
                RuleItemCard(
                    title = if (isSw) "2. Mwendo wa Kete ya Kawaida (Men Movement)" else "2. Ordinary Piece (Men) Movement",
                    content = if (isSw) {
                        "Kete ya kawaida hutembea hatua moja mbele kimshazari (diagonally forward) kwenye mraba tupu wa giza unaofuata.\n\nKete ya kawaida hairuhusiwi kurudi nyuma katika mchezo wa kawaida usio wa kula."
                    } else {
                        "An ordinary man moves one square diagonally forward into an adjacent empty dark square.\n\nA man cannot move backward during normal non-capturing moves."
                    }
                )
            }

            item {
                RuleItemCard(
                    title = if (isSw) "3. Sheria ya Kula kwa Lazima (Mandatory Capture)" else "3. Mandatory Capture Rule",
                    content = if (isSw) {
                        "IWAPO kuna fursa yoyote ya kula kete ya mpinzani, MCHEZAJI LAZIMA ALE! Miondoko ya kawaida ya kukwepa au kusogeza kete nyingine bila kula imepigwa marufuku kabisa na injini itamzuia mchezaji.\n\nKatika kanuni ya Ligi ya Tanzania, mchezaji anapewa uhuru wa kuchagua njia yoyote halali ya kula iwapo kuna njia zaidi ya moja (Free Choice), isipokuwa ligi ikibainisha kanuni ya kula kete nyingi zaidi (Maximum Pieces)."
                    } else {
                        "IF a legal capture exists, CAPTURE IS STRICTLY MANDATORY! Non-capturing moves are completely prohibited when a capture opportunity is on the board.\n\nUnder default Tanzania League regulations, the player has free choice among legal capture paths unless maximum-pieces capture profile is selected by the administrator."
                    }
                )
            }

            item {
                RuleItemCard(
                    title = if (isSw) "4. Kula Mfululizo (Multiple Consecutive Jumps)" else "4. Multiple Consecutive Captures",
                    content = if (isSw) {
                        "Iwapo kete imeruka na kula kete ya mpinzani, na kutoka mraba ilipotua bado inaweza kula kete nyingine ya mpinzani, mzunguko wa mchezaji hauishi! Ni lazima aendelee kuruka na kula hadi hakuna fursa nyingine ya kula.\n\nKete zilizoliwa huondolewa mara moja kwenye ubao."
                    } else {
                        "If a piece jumps and captures, and from its landing square another capture is legally available, the turn continues! The player must continue capturing in the same turn until no further captures remain."
                    }
                )
            }

            item {
                RuleItemCard(
                    title = if (isSw) "5. Mfalme Arukaye (Flying King / Mfalme)" else "5. Flying King (Mfalme Arukaye)",
                    content = if (isSw) {
                        "Kete ya kawaida inapofika mstari wa mwisho wa upande wa mpinzani, inatawazwa papo hapo kuwa MFALME (Crown / Mfalme 👑).\n\nMfalme wa Kitanzania ni MFALME ARUKAYE (Long-range Flying King): ana uwezo wa kuruka umbali wowote kimshazari mbele au nyuma katika njia iliyo wazi.\n\nPia mfalme anaweza kula kete ya mpinzani iliyopo mbali kimshazari na kutua kwenye mraba wowote tupu ulio wazi nyuma ya kete iliyoliwa!"
                    } else {
                        "When an ordinary man reaches the opponent's back rank, it is crowned immediately as a KING (Mfalme 👑).\n\nIn Tanzania Draughts, the King is a FLYING KING (long-range): it can glide any distance diagonally forward or backward across open squares.\n\nA flying king can capture an opponent piece at long range and land on ANY open dark square beyond the jumped piece along the diagonal."
                    }
                )
            }

            item {
                RuleItemCard(
                    title = if (isSw) "6. Ushindi na Sare (Victory & Draw Conditions)" else "6. Victory & Draw Conditions",
                    content = if (isSw) {
                        "• Ushindi: Mchezaji anashinda iwapo amekula kete zote za mpinzani au mpinzani hana hatua yoyote halali iliyobaki (amefungwa/kuzuiwa kabisa).\n• Sare: Mchezo hufikia sare iwapo miondoko 40 itapita bila kete yoyote kuliwa, au wachezaji wote wawili wakikubaliana sare kwa hiari."
                    } else {
                        "• Victory: Achieved when you capture all opponent pieces, or when the opponent has no legal moves remaining (completely blocked).\n• Draw: Declared if 40 half-moves elapse without any piece being captured, or by mutual agreement."
                    }
                )
            }
        }
    }
}

@Composable
fun RuleItemCard(title: String, content: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TzDarkCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGreenPrimary, TzGoldWarm.copy(alpha = 0.5f))))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = TzGoldAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}
