package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TzGoldAccent,
    onPrimary = Color.Black,
    primaryContainer = TzGreenPrimary,
    onPrimaryContainer = Color.White,
    secondary = TzGreenLight,
    onSecondary = Color.White,
    secondaryContainer = TzDarkSurfaceVariant,
    onSecondaryContainer = Color.White,
    tertiary = TzSkyBlue,
    onTertiary = Color.Black,
    background = TzDarkBg,
    onBackground = Color(0xFFEEEEEE),
    surface = TzDarkSurface,
    onSurface = Color(0xFFEEEEEE),
    surfaceVariant = TzDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCCCCCC),
    outline = Color(0xFF3B4F3F),
    error = Color(0xFFFF5252)
)

private val LightColorScheme = lightColorScheme(
    primary = TzGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8F5E9),
    onPrimaryContainer = TzGreenDark,
    secondary = TzGoldWarm,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFFFFF8E1),
    onSecondaryContainer = Color(0xFF5D4037),
    tertiary = TzSkyBlue,
    onTertiary = Color.White,
    background = Color(0xFFF7F9F7),
    onBackground = Color(0xFF1B1B1B),
    surface = Color.White,
    onSurface = Color(0xFF1B1B1B),
    surfaceVariant = Color(0xFFE8EFE8),
    onSurfaceVariant = Color(0xFF3E4D40),
    outline = Color(0xFF81C784),
    error = Color(0xFFD32F2F)
)

@Composable
fun TanzaniaDraughtsTheme(
    darkTheme: Boolean = true, // Default to stunning dark esports theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backwards-compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TanzaniaDraughtsTheme(darkTheme = true, content = content)
}
