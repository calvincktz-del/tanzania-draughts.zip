package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun LeagueScreen(
    leagues: List<League>,
    standings: List<LeagueParticipant>,
    fixtures: List<Fixture>,
    language: AppLanguage,
    onRegisterLeague: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI
    var selectedTab by remember { mutableStateOf(0) } // 0: Standings, 1: Fixtures, 2: Leagues Directory

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("league_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_league_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) "Ligi Kuu ya Rasimu Tanzania" else "Tanzania Draughts League",
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "Msimu wa 2026/2027 • Saa za Afrika/Dar es Salaam" else "2026/2027 Season • Africa/Dar_es_Salaam",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = TzDarkCard,
            contentColor = TzGoldAccent,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = TzGoldAccent
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(if (isSw) "Msimamo" else "Standings", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(if (isSw) "Ratiba ya Mechi" else "Fixtures", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text(if (isSw) "Ligi Zote" else "Directory", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
        }

        when (selectedTab) {
            0 -> StandingsTab(standings = standings, isSw = isSw)
            1 -> FixturesTab(fixtures = fixtures, isSw = isSw)
            2 -> DirectoryTab(leagues = leagues, isSw = isSw, onRegister = onRegisterLeague)
        }
    }
}

@Composable
fun StandingsTab(standings: List<LeagueParticipant>, isSw: Boolean) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Table Header
        item {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = TzGreenDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "#", color = TzGoldAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(24.dp))
                    Text(text = if (isSw) "Mchezaji" else "Player", color = TzGoldAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    Text(text = "MP", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(28.dp))
                    Text(text = "W", color = Color(0xFF81C784), fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(24.dp))
                    Text(text = "D", color = Color.White.copy(alpha = 0.7f), fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(24.dp))
                    Text(text = "L", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(24.dp))
                    Text(text = "Pts", color = TzGoldAccent, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.width(32.dp))
                }
            }
        }

        items(standings) { player ->
            val isLeader = player.rank == 1
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isLeader) TzGreenPrimary.copy(alpha = 0.35f) else TzDarkCard
                ),
                border = if (isLeader) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzGreenLight))) else null
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Rank
                        Text(
                            text = "${player.rank}",
                            color = if (isLeader) TzGoldAccent else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.width(24.dp)
                        )

                        // Name & Club
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = player.avatarEmoji, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = player.playerName,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "${player.clubOrRegion} • Elo ${player.skillRating}",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 10.sp
                            )
                        }

                        // Stats
                        Text(text = "${player.matchesPlayed}", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(28.dp))
                        Text(text = "${player.wins}", color = Color(0xFF81C784), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
                        Text(text = "${player.draws}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.width(24.dp))
                        Text(text = "${player.losses}", color = Color(0xFFFF5252), fontSize = 12.sp, modifier = Modifier.width(24.dp))
                        Text(
                            text = "${player.points}",
                            color = TzGoldAccent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.width(32.dp)
                        )
                    }

                    // Form dots row
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSw) "Mwelekeo: " else "Form: ",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 9.sp
                        )
                        player.form.takeLast(5).forEach { f ->
                            val color = when (f) {
                                "W" -> Color(0xFF81C784)
                                "D" -> Color(0xFFFFB74D)
                                else -> Color(0xFFFF5252)
                            }
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .size(14.dp)
                                    .background(color, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = f, color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FixturesTab(fixtures: List<Fixture>, isSw: Boolean) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(fixtures) { fix ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = TzDarkCard)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TzGreenPrimary
                        ) {
                            Text(
                                text = fix.roundLabel,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Text(
                            text = fix.scheduledTime,
                            color = TzGoldAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = fix.playerA,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TzDarkSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        ) {
                            Text(
                                text = if (fix.status == FixtureStatus.COMPLETED) "${fix.scoreA} - ${fix.scoreB}" else "VS",
                                color = if (fix.status == FixtureStatus.COMPLETED) TzGoldAccent else Color.White.copy(alpha = 0.6f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = fix.playerB,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (fix.winner != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${if (isSw) "Mshindi" else "Winner"}: ${fix.winner}",
                            color = Color(0xFF81C784),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DirectoryTab(
    leagues: List<League>,
    isSw: Boolean,
    onRegister: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(leagues) { league ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TzDarkCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGreenPrimary, TzGoldWarm)))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSw) league.nameSwahili else league.name,
                            color = TzGoldAccent,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when (league.status) {
                                LeagueStatus.ACTIVE -> TzGreenLight
                                LeagueStatus.REGISTRATION_OPEN -> Color(0xFF0D47A1)
                                else -> Color.Gray
                            }
                        ) {
                            Text(
                                text = when (league.status) {
                                    LeagueStatus.ACTIVE -> if (isSw) "Inaendelea" else "Active"
                                    LeagueStatus.REGISTRATION_OPEN -> if (isSw) "Usajili Wazi" else "Reg Open"
                                    else -> "Draft"
                                },
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isSw) league.descriptionSwahili else league.description,
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Divisheni: ${league.division} • Sheria: ${league.rulesetVersion}",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Washiriki: ${league.registeredCount}/${league.participantCapacity}",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }

                        if (league.isRegistered) {
                            FilledTonalButton(
                                onClick = {},
                                enabled = false,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = TzGreenDark, contentColor = Color(0xFF81C784))
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isSw) "Umesajiliwa" else "Registered", fontSize = 11.sp)
                            }
                        } else {
                            Button(
                                onClick = { onRegister(league.leagueId) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black)
                            ) {
                                Text(if (isSw) "Jiandikishe" else "Register", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
