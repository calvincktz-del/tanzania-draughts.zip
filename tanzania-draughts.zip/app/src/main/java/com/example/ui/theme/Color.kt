package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tanzania Draughts League Palette (Dark Green, Gold, Obsidian, White & Tanzanian accents)
val TzGreenPrimary = Color(0xFF1B5E20)
val TzGreenLight = Color(0xFF2E7D32)
val TzGreenDark = Color(0xFF0B3B17)
val TzGoldAccent = Color(0xFFFFD700)
val TzGoldWarm = Color(0xFFD4AF37)
val TzSkyBlue = Color(0xFF00A3DD)
val TzYellowFlag = Color(0xFFFCD116)

// Dark Theme Surfaces
val TzDarkBg = Color(0xFF111712)
val TzDarkSurface = Color(0xFF18221A)
val TzDarkSurfaceVariant = Color(0xFF243327)
val TzDarkCard = Color(0xFF1F2B21)

// Board & Piece Colors
val BoardDarkDefault = Color(0xFF1C3A27)
val BoardLightDefault = Color(0xFFE8ECE9)
val PieceP1Light = Color(0xFFF7F7F7)
val PieceP1Border = Color(0xFFD4AF37)
val PieceP2Dark = Color(0xFF1A1A1A)
val PieceP2Border = Color(0xFF4CAF50)
val MoveHighlightDot = Color(0xAAFFD700)
val CaptureHighlight = Color(0xDDFF5252)
