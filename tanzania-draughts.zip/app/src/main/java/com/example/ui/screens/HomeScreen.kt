package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.PlayerProfile
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    profile: PlayerProfile,
    language: AppLanguage,
    onStartAI: () -> Unit,
    onStartLocal2P: () -> Unit,
    onStartOnline: () -> Unit,
    onStartPractice: () -> Unit,
    onNavigateLeagues: () -> Unit,
    onNavigateTournaments: () -> Unit,
    onNavigateProfile: () -> Unit,
    onNavigateRules: () -> Unit,
    onNavigateSettings: () -> Unit,
    onNavigateAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // App Bar / Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(TzGreenDark)
                            .border(1.5.dp, TzGoldAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_draughts_logo),
                            contentDescription = "Logo",
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "TANZANIA DRAUGHTS",
                            color = TzGoldAccent,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = if (isSw) "Ligi Kuu ya Rasimu 🇹🇿" else "Official Draughts League 🇹🇿",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onNavigateAdmin,
                        modifier = Modifier
                            .size(38.dp)
                            .background(TzDarkSurfaceVariant, CircleShape)
                            .testTag("btn_admin_top")
                    ) {
                        Icon(
                            Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin",
                            tint = TzGoldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = onNavigateSettings,
                        modifier = Modifier
                            .size(38.dp)
                            .background(TzDarkSurfaceVariant, CircleShape)
                            .testTag("btn_settings_top")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Profile Badge Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { onNavigateProfile() }
                    .testTag("profile_card_home"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TzDarkCard),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGreenPrimary, TzGoldAccent)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(TzGreenPrimary, TzGreenDark)))
                            .border(2.dp, TzGoldAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = profile.avatarEmoji, fontSize = 28.sp)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = profile.displayName,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "${profile.region} • ${profile.division}",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Rating badge
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = TzGoldAccent.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "Elo ${profile.skillRating}",
                                    color = TzGoldAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Level ${profile.level} (${profile.xp}/${profile.nextLevelXp} XP)",
                                color = Color(0xFF81C784),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.4f)
                    )
                }
            }
        }

        // Active League Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { onNavigateLeagues() }
                    .testTag("league_banner_home"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TzGreenDark)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isSw) "Ligi Kuu ya Rasimu Tanzania" else "Tanzania Premier League",
                                color = TzGoldAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TzGreenLight
                        ) {
                            Text(
                                text = if (isSw) "Nafasi ya 1" else "Rank #1",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isSw) "Mechi Ijayo: dhidi ya Bakari 'Kete' Salum (Kariakoo)" else "Upcoming Match: vs Bakari Salum (Kariakoo)",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (isSw) "Muda: 29 Oktoba 2026, 16:00 EAT • Ubao: 8x8 Rasimu ya Tanzania" else "Time: Oct 29, 2026, 16:00 EAT • Rules: 8x8 Tanzania Draughts",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Game Modes Section Title
        item {
            Text(
                text = if (isSw) "MCHEZO WA RASIMU" else "GAME MODES",
                color = TzGoldAccent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 6.dp)
            )
        }

        // Game Mode Cards Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GameModeCard(
                    title = if (isSw) "Cheza na Kompyuta (AI)" else "Play vs AI Opponent",
                    subtitle = if (isSw) "Ngazi 5: Mwanzilishi hadi Gwiji (Expert)" else "5 Levels: Beginner to Expert Minimax",
                    icon = Icons.Default.SmartToy,
                    badgeText = if (isSw) "Bila Intaneti (Offline)" else "Offline Supported",
                    gradientColors = listOf(Color(0xFF1B5E20), Color(0xFF0F3820)),
                    testTag = "btn_mode_ai",
                    onClick = onStartAI
                )

                GameModeCard(
                    title = if (isSw) "Wachezaji 2 (Kifaa Kimoja)" else "Pass & Play (Local 2P)",
                    subtitle = if (isSw) "Cheza ana kwa ana na rafiki yako kwenye simu" else "Challenge a friend on the same device",
                    icon = Icons.Default.People,
                    badgeText = if (isSw) "Wachezaji 2" else "2 Players",
                    gradientColors = listOf(Color(0xFF0D47A1), Color(0xFF072757)),
                    testTag = "btn_mode_local2p",
                    onClick = onStartLocal2P
                )

                GameModeCard(
                    title = if (isSw) "Mechi ya Mtandaoni (Multiplayer)" else "Online Multiplayer & Rooms",
                    subtitle = if (isSw) "Mechi za viwango (Ranked) au Chumba cha Siri" else "Ranked matchmaking or Private invite code",
                    icon = Icons.Default.Public,
                    badgeText = if (isSw) "Mtandaoni" else "Live Online",
                    gradientColors = listOf(Color(0xFFB71C1C), Color(0xFF5D0E0E)),
                    testTag = "btn_mode_online",
                    onClick = onStartOnline
                )

                GameModeCard(
                    title = if (isSw) "Ubao wa Mazoezi Huria" else "Practice & Training Mode",
                    subtitle = if (isSw) "Jifunze kula kwa lazima na mbinu za mfalme" else "Master mandatory capture & flying king",
                    icon = Icons.Default.School,
                    badgeText = if (isSw) "Mazoezi" else "Practice",
                    gradientColors = listOf(Color(0xFF37474F), Color(0xFF212121)),
                    testTag = "btn_mode_practice",
                    onClick = onStartPractice
                )
            }
        }

        // Quick Hub Section Title
        item {
            Text(
                text = if (isSw) "LIGI NA MASHINDANO YA TANZANIA" else "LEAGUES & COMPETITION",
                color = TzGoldAccent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 6.dp)
            )
        }

        // Quick Hub Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickHubItem(
                    title = if (isSw) "Ligi & Msimamo" else "Standings",
                    icon = Icons.Default.FormatListNumbered,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_standings",
                    onClick = onNavigateLeagues
                )

                QuickHubItem(
                    title = if (isSw) "Kombe Mtoano" else "Tournaments",
                    icon = Icons.Default.MilitaryTech,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_tournament",
                    onClick = onNavigateTournaments
                )

                QuickHubItem(
                    title = if (isSw) "Sheria za Dama" else "Rules Guide",
                    icon = Icons.Default.MenuBook,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_quick_rules",
                    onClick = onNavigateRules
                )
            }
        }
    }
}

@Composable
fun GameModeCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badgeText: String,
    gradientColors: List<Color>,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = TzDarkCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(gradientColors))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(26.dp))
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 11.sp
                )
            }

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.4f)
            ) {
                Text(
                    text = badgeText,
                    color = TzGoldAccent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
fun QuickHubItem(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TzDarkCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(TzGreenLight.copy(alpha = 0.4f), Color.Transparent)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(26.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
