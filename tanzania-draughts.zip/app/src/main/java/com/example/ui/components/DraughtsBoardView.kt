package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.TanzaniaDraughtsEngine
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun DraughtsBoardView(
    gameState: GameState,
    boardTheme: BoardThemeStyle,
    isFlipped: Boolean = false,
    selectedPos: Position?,
    onSquareClicked: (Position) -> Unit,
    modifier: Modifier = Modifier
) {
    val legalMovesFromSelected = remember(gameState, selectedPos) {
        if (selectedPos != null) {
            TanzaniaDraughtsEngine.getLegalMovesForPosition(gameState, selectedPos)
        } else {
            emptyList()
        }
    }

    val legalTargetPositions = remember(legalMovesFromSelected) {
        legalMovesFromSelected.map { it.to }.toSet()
    }

    val legalCapturesFromSelected = remember(legalMovesFromSelected) {
        legalMovesFromSelected.filter { it.isCapture }.map { it.to }.toSet()
    }

    val piecesWithCaptures = remember(gameState) {
        val allLegal = TanzaniaDraughtsEngine.getLegalMoves(gameState, gameState.currentTurn)
        if (allLegal.any { it.isCapture }) {
            allLegal.filter { it.isCapture }.map { it.from }.toSet()
        } else {
            emptySet()
        }
    }

    val lastMove = gameState.moveHistory.lastOrNull()

    // Board container
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top File Letters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            for (col in 0..7) {
                val c = if (isFlipped) 7 - col else col
                Text(
                    text = ('A'.code + c).toChar().toString(),
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Board Frame
        Box(
            modifier = Modifier
                .aspectRatio(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(3.dp, Color(boardTheme.accentHex), RoundedCornerShape(12.dp))
                .shadow(10.dp, RoundedCornerShape(12.dp))
                .background(Color(boardTheme.darkSquareHex))
                .testTag("draughts_board")
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                for (rowIndex in 0..7) {
                    val row = if (isFlipped) 7 - rowIndex else rowIndex
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        for (colIndex in 0..7) {
                            val col = if (isFlipped) 7 - colIndex else colIndex
                            val pos = Position(row, col)
                            val isDark = pos.isDarkSquare
                            val squareColor = if (isDark) {
                                Color(boardTheme.darkSquareHex)
                            } else {
                                Color(boardTheme.lightSquareHex)
                            }

                            val piece = gameState.pieceAt(pos)
                            val isSelected = selectedPos == pos
                            val isTarget = pos in legalTargetPositions
                            val isCaptureTarget = pos in legalCapturesFromSelected
                            val isMustCapturePiece = pos in piecesWithCaptures
                            val isLastMoveStep = lastMove != null && (lastMove.from == pos || lastMove.to == pos)

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(squareColor)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        onSquareClicked(pos)
                                    }
                                    .testTag("square_${pos.toNotation()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                // Last move highlight trail
                                if (isLastMoveStep) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color(0x33FFD700))
                                    )
                                }

                                // Piece rendering
                                if (piece != null) {
                                    DraughtsPieceView(
                                        piece = piece,
                                        isSelected = isSelected,
                                        isMustCapture = isMustCapturePiece
                                    )
                                }

                                // Legal Move indicator
                                if (isTarget) {
                                    if (isCaptureTarget) {
                                        // Capture target dot (Red ring)
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .border(3.dp, Color(0xFFFF5252), CircleShape)
                                                .background(Color(0x66FF5252), CircleShape)
                                        )
                                    } else {
                                        // Ordinary move target dot (Gold dot)
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .background(Color(boardTheme.accentHex).copy(alpha = 0.85f), CircleShape)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom File Letters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            for (col in 0..7) {
                val c = if (isFlipped) 7 - col else col
                Text(
                    text = ('A'.code + c).toChar().toString(),
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun DraughtsPieceView(
    piece: DraughtsPiece,
    isSelected: Boolean,
    isMustCapture: Boolean,
    modifier: Modifier = Modifier
) {
    val isP1 = piece.player == Player.PLAYER_1

    val outerColor = if (isP1) Color(0xFFEBEBEB) else Color(0xFF1E211E)
    val innerColor = if (isP1) Color(0xFFFFFFFF) else Color(0xFF2C352E)
    val ringBorder = if (isP1) Color(0xFFC0A040) else Color(0xFF2E7D32)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val scaleModifier = if (isMustCapture || isSelected) {
        Modifier.size((36 * pulseScale).dp)
    } else {
        Modifier.size(36.dp)
    }

    Box(
        modifier = modifier
            .then(scaleModifier)
            .shadow(if (isSelected) 8.dp else 4.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(innerColor, outerColor)
                )
            )
            .border(
                width = if (isSelected) 3.dp else if (isMustCapture) 2.5.dp else 1.5.dp,
                color = if (isSelected) TzGoldAccent else if (isMustCapture) Color(0xFFFF5252) else ringBorder,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        // Inner grooved ring
        Box(
            modifier = Modifier
                .size(22.dp)
                .border(1.dp, ringBorder.copy(alpha = 0.7f), CircleShape)
        )

        // Crown for King (Mfalme)
        if (piece.isKing) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Mfalme (King)",
                    tint = TzGoldAccent,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
