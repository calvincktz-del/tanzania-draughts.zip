package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AIDifficulty
import com.example.engine.DraughtsAI
import com.example.engine.TanzaniaDraughtsEngine
import com.example.model.*
import com.example.ui.components.DraughtsBoardView
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class PlayMode {
    AI,
    LOCAL_2P,
    PRACTICE,
    ONLINE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    mode: PlayMode,
    initialDifficulty: AIDifficulty = AIDifficulty.MEDIUM,
    boardTheme: BoardThemeStyle,
    language: AppLanguage,
    onBackToHome: () -> Unit,
    onRecordResult: (result: String, opponent: String, rating: Int, moves: List<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI
    val coroutineScope = rememberCoroutineScope()

    var aiDifficulty by remember { mutableStateOf(initialDifficulty) }
    val aiEngine = remember(aiDifficulty) { DraughtsAI(aiDifficulty) }

    var gameState by remember { mutableStateOf(GameState.initial()) }
    var selectedPosition by remember { mutableStateOf<Position?>(null) }
    var isFlipped by remember { mutableStateOf(false) }
    var isAiThinking by remember { mutableStateOf(false) }
    var showGameOverDialog by remember { mutableStateOf(false) }
    var showDifficultySheet by remember { mutableStateOf(false) }

    val hasMandatoryCapture = remember(gameState) {
        TanzaniaDraughtsEngine.hasCapture(gameState, gameState.currentTurn)
    }

    // Trigger AI move when it's Player 2's turn in AI mode
    LaunchedEffect(gameState.currentTurn, gameState.status, mode) {
        if (mode == PlayMode.AI && gameState.currentTurn == Player.PLAYER_2 && !gameState.isGameOver) {
            isAiThinking = true
            delay(500) // Realistic move animation delay
            val bestMove = aiEngine.findBestMove(gameState)
            if (bestMove != null) {
                gameState = TanzaniaDraughtsEngine.makeMove(gameState, bestMove)
            }
            isAiThinking = false
        }
    }

    // Handle Game Over
    LaunchedEffect(gameState.status) {
        if (gameState.isGameOver) {
            showGameOverDialog = true
            val resStr = when (gameState.status) {
                GameStatus.PLAYER_1_WON -> "WIN"
                GameStatus.PLAYER_2_WON -> "LOSS"
                else -> "DRAW"
            }
            val oppName = when (mode) {
                PlayMode.AI -> "Kompyuta AI (${aiDifficulty.name})"
                PlayMode.ONLINE -> "Mpinzani Mtandaoni"
                else -> "Mchezaji 2"
            }
            onRecordResult(resStr, oppName, 1550, gameState.moveHistory.map { it.notation() })
        }
    }

    fun handleSquareClick(pos: Position) {
        if (gameState.isGameOver || isAiThinking) return

        val currentTurn = gameState.currentTurn
        // In AI mode, user can only click when it's Player 1's turn
        if (mode == PlayMode.AI && currentTurn != Player.PLAYER_1) return

        val clickedPiece = gameState.pieceAt(pos)

        // If clicking own piece, select it
        if (clickedPiece != null && clickedPiece.player == currentTurn) {
            selectedPosition = pos
            return
        }

        // If a piece was already selected and user clicked a target square
        val selected = selectedPosition
        if (selected != null) {
            val legalMoves = TanzaniaDraughtsEngine.getLegalMovesForPosition(gameState, selected)
            val chosenMove = legalMoves.find { it.to == pos }
            if (chosenMove != null) {
                gameState = TanzaniaDraughtsEngine.makeMove(gameState, chosenMove)
                selectedPosition = null
            } else {
                selectedPosition = null
            }
        }
    }

    fun restartGame() {
        gameState = GameState.initial()
        selectedPosition = null
        showGameOverDialog = false
    }

    fun undoMove() {
        if (gameState.moveHistory.isNotEmpty()) {
            // Replay from initial to history - 1 (or - 2 if in AI mode)
            val stepsToUndo = if (mode == PlayMode.AI && gameState.moveHistory.size >= 2) 2 else 1
            val targetCount = (gameState.moveHistory.size - stepsToUndo).coerceAtLeast(0)
            var replayState = GameState.initial()
            for (i in 0 until targetCount) {
                replayState = TanzaniaDraughtsEngine.makeMove(replayState, gameState.moveHistory[i])
            }
            gameState = replayState
            selectedPosition = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("game_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToHome,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_game_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when (mode) {
                        PlayMode.AI -> if (isSw) "Dhidi ya AI (${aiDifficulty.name})" else "vs AI (${aiDifficulty.name})"
                        PlayMode.LOCAL_2P -> if (isSw) "Wachezaji 2 (Kifaa Kimoja)" else "Local 2 Players"
                        PlayMode.PRACTICE -> if (isSw) "Ubao wa Mazoezi" else "Practice Mode"
                        PlayMode.ONLINE -> if (isSw) "Mechi ya Mtandaoni" else "Online Ranked Match"
                    },
                    color = TzGoldAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "8x8 Rasimu ya Tanzania" else "8x8 Tanzania Draughts",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (mode == PlayMode.AI) {
                    IconButton(
                        onClick = { showDifficultySheet = true },
                        modifier = Modifier
                            .size(38.dp)
                            .background(TzDarkSurfaceVariant, CircleShape)
                            .testTag("btn_select_difficulty")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = "Difficulty", tint = TzGoldAccent)
                    }
                }

                IconButton(
                    onClick = { isFlipped = !isFlipped },
                    modifier = Modifier
                        .size(38.dp)
                        .background(TzDarkSurfaceVariant, CircleShape)
                        .testTag("btn_flip_board")
                ) {
                    Icon(Icons.Default.ScreenRotation, contentDescription = "Flip", tint = Color.White)
                }
            }
        }

        // Opponent (Player 2) Info Bar
        PlayerInfoBar(
            playerName = when (mode) {
                PlayMode.AI -> if (isSw) "Kompyuta AI (P2)" else "Computer AI (P2)"
                PlayMode.ONLINE -> if (isSw) "Mpinzani Mtandaoni" else "Online Opponent"
                else -> if (isSw) "Mchezaji 2 (Giza)" else "Player 2 (Dark)"
            },
            avatarEmoji = if (mode == PlayMode.AI) "🤖" else "🎯",
            isCurrentTurn = gameState.currentTurn == Player.PLAYER_2,
            capturedCount = gameState.capturedByP2,
            kingsCount = gameState.countKings(Player.PLAYER_2),
            isAiThinking = isAiThinking,
            isSw = isSw
        )

        // Mandatory Capture Alert Banner
        AnimatedVisibility(
            visible = hasMandatoryCapture,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                color = Color(0xFFB71C1C).copy(alpha = 0.9f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSw) "KULA KWA LAZIMA: Lazima uchague kete ya kula!" else "MANDATORY CAPTURE: You must capture!",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Interactive Board
        DraughtsBoardView(
            gameState = gameState,
            boardTheme = boardTheme,
            isFlipped = isFlipped,
            selectedPos = selectedPosition,
            onSquareClicked = { handleSquareClick(it) },
            modifier = Modifier.weight(1f, fill = false)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // User (Player 1) Info Bar
        PlayerInfoBar(
            playerName = if (isSw) "Wewe (Mchezaji 1)" else "You (Player 1)",
            avatarEmoji = "👑",
            isCurrentTurn = gameState.currentTurn == Player.PLAYER_1,
            capturedCount = gameState.capturedByP1,
            kingsCount = gameState.countKings(Player.PLAYER_1),
            isAiThinking = false,
            isSw = isSw
        )

        // Move History Notation Row
        if (gameState.moveHistory.isNotEmpty()) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .background(TzDarkSurfaceVariant, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(gameState.moveHistory) { index, move ->
                    val turnNum = (index / 2) + 1
                    val isP1 = index % 2 == 0
                    Text(
                        text = if (isP1) "$turnNum. ${move.notation()}" else move.notation(),
                        color = if (index == gameState.moveHistory.lastIndex) TzGoldAccent else Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = if (index == gameState.moveHistory.lastIndex) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Action Buttons Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Undo button (available in practice and local 2P)
            if (mode == PlayMode.PRACTICE || mode == PlayMode.LOCAL_2P || mode == PlayMode.AI) {
                OutlinedButton(
                    onClick = { undoMove() },
                    enabled = gameState.moveHistory.isNotEmpty() && !isAiThinking,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.testTag("btn_undo_move")
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isSw) "Rejea" else "Undo", fontSize = 12.sp)
                }
            }

            // Resign / Surrender button
            OutlinedButton(
                onClick = {
                    gameState = gameState.copy(status = GameStatus.PLAYER_1_RESIGNED)
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(Color(0xFFFF5252), Color(0xFFD32F2F)))),
                modifier = Modifier.testTag("btn_resign")
            ) {
                Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isSw) "Salimu Amri" else "Resign", fontSize = 12.sp)
            }

            // Restart button
            FilledTonalButton(
                onClick = { restartGame() },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = TzGreenPrimary, contentColor = Color.White),
                modifier = Modifier.testTag("btn_restart_game")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isSw) "Mpya" else "Restart", fontSize = 12.sp)
            }
        }
    }

    // Game Over Dialog
    if (showGameOverDialog) {
        AlertDialog(
            onDismissRequest = { showGameOverDialog = false },
            containerColor = TzDarkCard,
            title = {
                Text(
                    text = when (gameState.status) {
                        GameStatus.PLAYER_1_WON -> if (isSw) "HONGERA! USHINDI 🏆" else "VICTORY! 🏆"
                        GameStatus.PLAYER_2_WON -> if (isSw) "MPINZANI AMESHINDA 🎯" else "DEFEAT 🎯"
                        GameStatus.PLAYER_1_RESIGNED -> if (isSw) "UMESALIMU AMRI" else "YOU RESIGNED"
                        GameStatus.PLAYER_2_RESIGNED -> if (isSw) "MPINZANI KASALIMU AMRI" else "OPPONENT RESIGNED"
                        else -> if (isSw) "MCHEZO WA SARE 🤝" else "DRAW 🤝"
                    },
                    color = TzGoldAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = when (gameState.status) {
                            GameStatus.PLAYER_1_WON -> if (isSw) "Umekula kete zote za mpinzani au kumzuia asipate mchezo!" else "You captured all opponent pieces or blocked them!"
                            GameStatus.PLAYER_2_WON -> if (isSw) "Kete zako zote zimeliwa au umezuiwa." else "All your pieces were captured or blocked."
                            else -> if (isSw) "Mchezo umekamilika kwa sare." else "The match ended in a draw."
                        },
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = TzGreenPrimary.copy(alpha = 0.3f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Text(text = "+120 XP", color = TzGoldAccent, fontWeight = FontWeight.Bold)
                            Text(text = "+15 Elo", color = Color(0xFF81C784), fontWeight = FontWeight.Bold)
                            Text(text = "${gameState.moveHistory.size} Miondoko", color = Color.White)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showGameOverDialog = false
                        restartGame()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TzGoldAccent, contentColor = Color.Black)
                ) {
                    Text(if (isSw) "Cheza Tena" else "Play Again", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showGameOverDialog = false
                        onBackToHome()
                    }
                ) {
                    Text(if (isSw) "Menyu Kuu" else "Home Menu", color = Color.White)
                }
            }
        )
    }

    // AI Difficulty Selection Bottom Sheet
    if (showDifficultySheet) {
        ModalBottomSheet(
            onDismissRequest = { showDifficultySheet = false },
            containerColor = TzDarkCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = if (isSw) "Chagua Ugumu wa Kompyuta (AI)" else "Select AI Difficulty",
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(14.dp))

                AIDifficulty.values().forEach { diff ->
                    val isSelected = diff == aiDifficulty
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) TzGreenPrimary else Color.Transparent)
                            .clickable {
                                aiDifficulty = diff
                                showDifficultySheet = false
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = when (diff) {
                                    AIDifficulty.BEGINNER -> if (isSw) "Mwanzilishi (Beginner)" else "Beginner"
                                    AIDifficulty.EASY -> if (isSw) "Rahisi (Easy)" else "Easy"
                                    AIDifficulty.MEDIUM -> if (isSw) "Wastani (Medium)" else "Medium"
                                    AIDifficulty.HARD -> if (isSw) "Ngumu (Hard)" else "Hard"
                                    AIDifficulty.EXPERT -> if (isSw) "Gwiji (Expert Minimax)" else "Expert Minimax"
                                },
                                color = Color.White,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = TzGoldAccent)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerInfoBar(
    playerName: String,
    avatarEmoji: String,
    isCurrentTurn: Boolean,
    capturedCount: Int,
    kingsCount: Int,
    isAiThinking: Boolean,
    isSw: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentTurn) TzDarkCard else TzDarkSurfaceVariant.copy(alpha = 0.5f)
        ),
        border = if (isCurrentTurn) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzGreenLight))) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (isCurrentTurn) TzGreenPrimary else Color(0xFF2C352E)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = avatarEmoji, fontSize = 18.sp)
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = playerName,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = if (isCurrentTurn) FontWeight.Bold else FontWeight.Medium
                        )
                        if (isAiThinking) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isSw) "Inawaza..." else "Thinking...",
                                color = TzGoldAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "${if (isSw) "Kete Zilizoliwa" else "Captured"}: $capturedCount/12",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                        if (kingsCount > 0) {
                            Text(
                                text = "👑 $kingsCount ${if (isSw) "Wafalme" else "Kings"}",
                                color = TzGoldAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Turn Indicator Pill
            if (isCurrentTurn) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = TzGoldAccent
                ) {
                    Text(
                        text = if (isSw) "ZAMU YAKE" else "TURN",
                        color = Color.Black,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }
    }
}
