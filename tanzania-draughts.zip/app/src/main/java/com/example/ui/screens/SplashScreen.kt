package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.ui.theme.*

@Composable
fun SplashScreen(
    language: AppLanguage,
    onToggleLanguage: () -> Unit,
    onStartGame: () -> Unit,
    onOpenRules: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0B2913),
                        Color(0xFF111712),
                        Color(0xFF0A130C)
                    )
                )
            )
            .padding(24.dp)
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Language switcher top right
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalButton(
                onClick = onToggleLanguage,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = TzDarkSurfaceVariant,
                    contentColor = TzGoldAccent
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("btn_language_toggle")
            ) {
                Icon(Icons.Default.Language, contentDescription = "Lugha", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSw) "English" else "Kiswahili",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // App Emblem
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .border(3.dp, TzGoldAccent, CircleShape)
                    .background(Color(0xFF0B3B17)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_draughts_logo),
                    contentDescription = "Tanzania Draughts League Logo",
                    modifier = Modifier.size(120.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Title
            Text(
                text = "TANZANIA DRAUGHTS LEAGUE",
                color = TzGoldAccent,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = if (isSw) "Ligi Kuu ya Rasimu Tanzania 🇹🇿" else "Official Tanzania Draughts Esports 🇹🇿",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Subtitle info badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1B5E20).copy(alpha = 0.6f)
                ) {
                    Text(
                        text = if (isSw) "Sheria Halisi za Dama" else "Authentic Tanzania Rules",
                        color = Color(0xFF81C784),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0D47A1).copy(alpha = 0.6f)
                ) {
                    Text(
                        text = if (isSw) "Bila Kamari (Skill Sport)" else "100% Skill Sport",
                        color = Color(0xFF90CAF9),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Start Button
            Button(
                onClick = onStartGame,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_enter_game"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TzGoldAccent,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSw) "INGIA UWANJANI" else "ENTER ARENA",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Rules button
            OutlinedButton(
                onClick = onOpenRules,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_splash_rules"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzGreenLight))),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(20.dp), tint = TzGoldAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSw) "Soma Sheria za Dama" else "Read Draughts Rules",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Footer compliance note
        Text(
            text = if (isSw) "Inatii Sheria ya Data (PDPA 2022) & Sheria ya Michezo ya Tanzania" else "Compliant with Tanzania PDPA 2022 & Gaming Act (Pure Skill Sport)",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 10.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
        )
    }
}
