package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.*

@Composable
fun LegalScreen(
    language: AppLanguage,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("legal_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_legal_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) "Uzingatiaji wa Sheria za Tanzania" else "Tanzania Legal Compliance Hub",
                    color = TzGoldAccent,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "Sheria ya Michezo ya Kubahatisha & Sheria ya Data 2022" else "Gaming Act Cap 41 & Data Protection Act 2022",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Gaming Act Ch. 41 Non-Gambling Statement
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = TzGreenDark),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzGreenLight)))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Gavel, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSw) "TAMKO RASMI: MCHEZO WA AKILI (SKILL SPORT)" else "GAMING ACT CAP 41: SKILL SPORT DECLARATION",
                                color = TzGoldAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isSw) {
                                "Mchezo wa Tanzania Draughts League (Rasimu) ni mchezo wa kiakili na mbinu (100% Skill-based sport). Programu hii HAINA kamari, HAINA ubashiri wa fedha (betting), HAINA pochi za fedha wala ada za fedha za kuingilia mashindano.\n\nZawadi zote ni za kidijitali na kiheshima (XP, mataji, na hadhi ya viwango vya ligi pekee) kwa mujibu wa Sheria ya Michezo ya Kubahatisha (The Gaming Act, Chapter 41, R.E. 2023)."
                            } else {
                                "Tanzania Draughts League is strictly a skill-based board game and intellectual sport. This platform DOES NOT host wagering, cash betting, real-money entry fees, or cash-out wallets.\n\nAll rewards are non-monetary (XP, in-game trophies, cosmetics, and competitive Elo ranking) in compliance with The Gaming Act, Chapter 41, Revised Edition 2023."
                            },
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // Privacy Policy & PDPA 2022
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = TzSkyBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSw) "Sera ya Faragha (PDPA 2022)" else "Privacy Policy (PDPA 2022)",
                                color = TzGoldAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isSw) {
                                "Kwa mujibu wa Sheria ya Ulinzi wa Taarifa Binafsi ya Tanzania (Personal Data Protection Act, 2022):\n" +
                                "1. Ukusanyaji wa Taarifa: Tunakusanya tu jina la mtumiaji (username), mkoa, na alama za mchezo kwa madhumuni ya kuendesha ligi.\n" +
                                "2. Haki za Mtumiaji: Mtumiaji ana haki ya kukagua taarifa zake, kuzirekebisha, au kuomba kufutwa kabisa kwa akaunti na data zake wakati wowote kupitia menyu ya Mipangilio.\n" +
                                "3. Usalama wa Data: Data zote zinalindwa na hazitauzwa wala kutolewa kwa mashirika mengine."
                            } else {
                                "Pursuant to the Personal Data Protection Act, 2022 (PDPA):\n" +
                                "1. Data Minimization: We only store usernames, regional affiliation, and match statistics necessary for league administration.\n" +
                                "2. Data Subject Rights: Users have the right to access, rectify, or request permanent deletion of their profile and data at any time via Settings.\n" +
                                "3. Security & Non-Disclosure: Personal data is safeguarded and never commercialized or shared with unauthorized third parties."
                            },
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // Terms and Fair Play
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Policy, contentDescription = null, tint = TzGoldWarm, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSw) "Masharti na Kanuni za Michezo ya Haki" else "Terms of Service & Fair Play Code",
                                color = TzGoldAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isSw) {
                                "• Uchezaji wa Haki: Matumizi ya programu za nje (bots) au kudanganya mtandao yamepigwa marufuku.\n" +
                                "• Adhabu: Mchezaji yeyote anayevunja kanuni anaweza kusimamishwa au kuondolewa kwenye ligi baada ya uchunguzi wa kamati ya usuluhishi.\n" +
                                "• Rufaa: Mchezaji anayo haki ya kuwasilisha rufaa dhidi ya adhabu yoyote kwa msimamizi wa ligi."
                            } else {
                                "• Fair Play: Use of external bots, match manipulation, or intentional disconnect exploits is strictly prohibited.\n" +
                                "• Sanctions: Infractions may result in rating disqualification or league suspension following referee investigation.\n" +
                                "• Appeals: Players maintain the right to appeal any disciplinary measure to the League Administrator."
                            },
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // Regulatory Authorities References
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TzDarkSurfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isSw) "Mamlaka za Kisheria za Tanzania Zinazorejelewa:" else "Official Regulatory References (Tanzania):",
                            color = TzGoldAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "• Ofisi ya Mwanasheria Mkuu wa Serikali (OAG): https://oagmis.oag.go.tz", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text(text = "• Bodi ya Michezo ya Kubahatisha Tanzania (GBT): https://www.gamingboard.go.tz", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text(text = "• Tume ya Ulinzi wa Taarifa Binafsi (PDPC): https://www.pdpc.go.tz", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
