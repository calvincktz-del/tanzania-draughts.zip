package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.TournamentBracket
import com.example.model.TournamentMatch
import com.example.ui.theme.*

@Composable
fun TournamentScreen(
    tournament: TournamentBracket,
    language: AppLanguage,
    onPlayTournamentMatch: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSw = language == AppLanguage.SWAHILI

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TzDarkBg)
            .statusBarsPadding()
            .testTag("tournament_screen")
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .background(TzDarkSurfaceVariant, CircleShape)
                    .testTag("btn_tournament_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isSw) tournament.nameSwahili else tournament.name,
                    color = TzGoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isSw) "Mashindano ya Mtoano ya Kitaifa 🇹🇿" else "National Knockout Tournament 🇹🇿",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Trophy Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = TzGreenDark),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzGreenLight)))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(TzGoldAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = TzGoldAccent, modifier = Modifier.size(32.dp))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = if (isSw) "Taji Kuu la Muungano 2026" else "Muungano Championship Cup",
                                color = TzGoldAccent,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isSw) "Zawadi: Kombe la Dhahabu, Hadhi ya Gwiji & XP 5,000" else "Rewards: Golden Trophy, Grandmaster Title & 5,000 XP",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Championship Final Section
            item {
                SectionHeader(title = if (isSw) "FAINALI KUU (CHAMPIONSHIP FINAL)" else "CHAMPIONSHIP FINAL")
                MatchBracketCard(
                    match = tournament.finalMatch,
                    isHighlight = true,
                    isSw = isSw,
                    onPlay = { onPlayTournamentMatch(tournament.finalMatch.matchId) }
                )
            }

            // Semifinals Section
            item {
                SectionHeader(title = if (isSw) "NUSU FAINALI (SEMIFINALS)" else "SEMIFINALS")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    tournament.semiFinals.forEach { match ->
                        MatchBracketCard(
                            match = match,
                            isHighlight = false,
                            isSw = isSw,
                            onPlay = { onPlayTournamentMatch(match.matchId) }
                        )
                    }
                }
            }

            // Quarterfinals Section
            item {
                SectionHeader(title = if (isSw) "ROBO FAINALI (QUARTERFINALS)" else "QUARTERFINALS")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    tournament.quarterFinals.forEach { match ->
                        MatchBracketCard(
                            match = match,
                            isHighlight = false,
                            isSw = isSw,
                            onPlay = { onPlayTournamentMatch(match.matchId) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        color = TzGoldAccent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
fun MatchBracketCard(
    match: TournamentMatch,
    isHighlight: Boolean,
    isSw: Boolean,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) TzDarkSurfaceVariant else TzDarkCard
        ),
        border = if (isHighlight) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TzGoldAccent, TzSkyBlue))) else null
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = match.roundName,
                color = if (isHighlight) TzGoldAccent else Color.White.copy(alpha = 0.6f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Player A
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Text(
                        text = match.playerA,
                        color = if (match.winner == match.playerA) TzGoldAccent else Color.White,
                        fontWeight = if (match.winner == match.playerA) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 13.sp
                    )
                    if (match.winner == match.playerA) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "👑", fontSize = 12.sp)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.4f),
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = if (match.scoreA != null && match.scoreB != null) "${match.scoreA} - ${match.scoreB}" else "VS",
                        color = TzGoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                // Player B
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                    if (match.winner == match.playerB) {
                        Text(text = "👑", fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = match.playerB,
                        color = if (match.winner == match.playerB) TzGoldAccent else Color.White,
                        fontWeight = if (match.winner == match.playerB) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 13.sp
                    )
                }
            }

            if (match.winner == null && match.playerA.isNotBlank() && !match.playerB.startsWith("Mshindi")) {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onPlay,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TzGreenPrimary, contentColor = Color.White)
                ) {
                    Text(if (isSw) "Cheza Mechi Hii Sasa" else "Play Match Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
